"""
Discovery Agent — main entry point.
Usage: python main.py --docs ./sample_docs --output ./output
"""

import os
import sys
import argparse
from pathlib import Path

from groq import Groq
from dotenv import load_dotenv
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.prompt import Prompt

from audit import configure_audit_log, log_event, get_audit_log_path
from loaders.loader import load_document
from extractor.extractor import extract_from_document
from validator.validator import validate_and_score
from output.writer import write_json, write_report

load_dotenv()
console = Console()

SUPPORTED_EXTENSIONS = {
    ".pdf", ".png", ".jpg", ".jpeg", ".webp",
    ".txt", ".md", ".html", ".htm",
    ".xlsx", ".xls", ".csv"
}


def main():
    parser = argparse.ArgumentParser(description="Discovery Agent")
    parser.add_argument("--docs", default="./sample_docs", help="Folder containing documents")
    parser.add_argument("--output", default="./output", help="Output folder")
    parser.add_argument("--interactive", action="store_true", help="Launch an interactive terminal UI")
    args = parser.parse_args()

    docs_path = Path(args.docs)
    if not docs_path.exists():
        console.print(f"[red]Error: docs folder not found: {docs_path}[/red]")
        sys.exit(1)

    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        console.print("[red]Error: GROQ_API_KEY not set in .env file[/red]")
        console.print("[yellow]Get a free key at: console.groq.com[/yellow]")
        sys.exit(1)

    client = Groq(api_key=api_key)

    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)
    configure_audit_log(output_path / "audit_log.jsonl")
    log_event("startup", docs=str(docs_path), output=str(output_path), interactive=args.interactive)

    doc_files = [
        f for f in docs_path.iterdir()
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not doc_files:
        console.print(f"[yellow]No supported documents found in {docs_path}[/yellow]")
        sys.exit(0)

    console.print(f"\n[bold]Discovery Agent[/bold] — found [cyan]{len(doc_files)}[/cyan] document(s)\n")

    if args.interactive:
        _interactive_session(client, doc_files, output_path)
        return

    _run_analysis(client, doc_files, output_path)


def _run_analysis(client, doc_files, output_path):
    console.print(f"[bold]Running analysis[/bold]\n")

    all_candidates = []
    errors = []
    processed = 0

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        for doc_file in doc_files:
            task = progress.add_task(f"Processing {doc_file.name}...", total=None)
            log_event("document_load_started", document=doc_file.name)
            loaded = load_document(str(doc_file))

            if loaded.load_error:
                errors.append(f"{doc_file.name}: {loaded.load_error}")
                progress.update(task, description=f"[yellow]⚠ {doc_file.name} — {loaded.load_error}[/yellow]")
                log_event("document_load_failed", document=doc_file.name, error=loaded.load_error)
                progress.stop_task(task)
                continue

            if not loaded.pages:
                errors.append(f"{doc_file.name}: no readable content")
                log_event("document_empty", document=doc_file.name)
                progress.stop_task(task)
                continue

            candidates = extract_from_document(client, loaded.pages, doc_file.name)
            all_candidates.extend(candidates)
            processed += 1
            log_event("document_extracted", document=doc_file.name, candidates=len(candidates))

            progress.update(task, description=f"[green]✓ {doc_file.name} — {len(candidates)} candidate(s) found[/green]")
            progress.stop_task(task)

    console.print(f"\n[bold]Validating and scoring {len(all_candidates)} candidate(s)...[/bold]")
    result = validate_and_score(all_candidates, processed, errors)
    log_event(
        "validation_complete",
        processed_documents=result.total_documents_processed,
        discovered=result.total_systems_discovered,
        review_count=result.systems_needing_review,
    )

    json_path = write_json(result, str(output_path))
    report_path = write_report(result, str(output_path))
    log_event("artifacts_written", json=json_path, report=report_path, audit=str(get_audit_log_path() or ""))

    _print_summary(result)
    console.print(f"\n[bold green]Output written:[/bold green]")
    console.print(f"  JSON   → {json_path}")
    console.print(f"  Report → {report_path}\n")
    console.print(f"  Audit  → {get_audit_log_path()}\n")


def _interactive_session(client, doc_files, output_path):
    console.print("[bold cyan]Interactive mode[/bold cyan]")
    while True:
        console.print("\n[bold]Choose an action:[/bold]")
        console.print("  1. Run discovery on all documents")
        console.print("  2. Preview a document")
        console.print("  3. Exit")
        choice = Prompt.ask("Select", choices=["1", "2", "3"], default="1")

        if choice == "1":
            _run_analysis(client, doc_files, output_path)
            continue

        if choice == "2":
            _preview_document(doc_files)
            continue

        console.print("Exiting interactive mode.")
        break


def _preview_document(doc_files):
    table = Table(title="Available Documents", show_header=True, header_style="bold")
    table.add_column("#", justify="right")
    table.add_column("Document")
    table.add_column("Type")

    for index, doc in enumerate(doc_files, start=1):
        table.add_row(str(index), doc.name, doc.suffix.lower().lstrip("."))
    console.print(table)

    selected = Prompt.ask("Enter document number", default="1")
    try:
        idx = max(1, min(int(selected), len(doc_files))) - 1
    except ValueError:
        idx = 0

    loaded = load_document(str(doc_files[idx]))
    if loaded.load_error:
        console.print(f"[red]{loaded.load_error}[/red]")
        return

    console.print(f"\n[bold]{loaded.filename}[/bold] — {len(loaded.pages)} page(s)")
    for page in loaded.pages[:3]:
        console.print(f"\n[cyan]Source:[/cyan] {page['source']}")
        console.print(page["text"][:1200])


def _print_summary(result):
    table = Table(title="Discovered Systems", show_header=True, header_style="bold")
    table.add_column("System", style="cyan")
    table.add_column("Category")
    table.add_column("Confidence", justify="right")
    table.add_column("Tier")
    table.add_column("Review?")

    for s in result.systems:
        tier_color = {"high": "green", "medium": "yellow", "low": "red"}.get(s.confidence_tier.value, "white")
        table.add_row(
            s.name,
            s.category.value,
            f"{s.confidence_score}%",
            f"[{tier_color}]{s.confidence_tier.value}[/{tier_color}]",
            "⚠️  Yes" if s.human_review_required else "✓ No",
        )

    console.print(table)
    console.print(f"\n[dim]{result.agent_notes}[/dim]")


if __name__ == "__main__":
    main()
