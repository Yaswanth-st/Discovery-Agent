"""
Output writer — produces both machine-readable JSON and a human-readable report.
"""

import json
from pathlib import Path
from datetime import datetime
from models import ExtractionResult, ConfidenceTier
from audit import get_audit_log_path


def write_json(result: ExtractionResult, output_dir: str = ".") -> str:
    """Write the structured JSON output."""
    path = Path(output_dir) / "discovery_result.json"
    path.write_text(
        json.dumps(result.model_dump(), indent=2, default=str),
        encoding="utf-8"
    )
    return str(path)


def write_report(result: ExtractionResult, output_dir: str = ".") -> str:
    """Write a human-readable Markdown report."""
    lines = []
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines.append(f"# Discovery Agent Report")
    lines.append(f"*Generated: {ts}*\n")
    lines.append(f"## Summary")
    lines.append(f"- Documents processed: **{result.total_documents_processed}**")
    lines.append(f"- Systems discovered: **{result.total_systems_discovered}**")
    lines.append(f"- Requiring human review: **{result.systems_needing_review}**")
    if get_audit_log_path():
        lines.append(f"- Audit log: `{get_audit_log_path()}`")
    lines.append(f"\n> {result.agent_notes}\n")

    if result.processing_errors:
        lines.append("## Processing Errors")
        for err in result.processing_errors:
            lines.append(f"- ⚠️  {err}")
        lines.append("")

    # High confidence systems
    high = [s for s in result.systems if s.confidence_tier == ConfidenceTier.HIGH]
    if high:
        lines.append("## High Confidence Systems (95%+)")
        for s in high:
            lines.append(f"\n### {s.name} `{s.confidence_score}%`")
            lines.append(f"- **Category:** {s.category.value}")
            lines.append(f"- **Criticality:** {s.criticality.value}")
            if s.auth_method:
                lines.append(f"- **Auth:** {s.auth_method}")
            if s.key_entities:
                lines.append(f"- **Entities:** {', '.join(s.key_entities)}")
            if s.business_processes:
                lines.append(f"- **Processes:** {', '.join(s.business_processes)}")
            lines.append(f"- **Evidence ({len(s.evidence_chain)} source(s)):**")
            for e in s.evidence_chain[:3]:
                lines.append(f'  - `{e.source_file}` — "{e.raw_text[:100]}"')

    # Medium confidence
    medium = [s for s in result.systems if s.confidence_tier == ConfidenceTier.MEDIUM]
    if medium:
        lines.append("\n## Medium Confidence Systems (70–94%)")
        for s in medium:
            lines.append(f"\n### {s.name} `{s.confidence_score}%`")
            lines.append(f"- **Category:** {s.category.value}")
            if s.inference_notes:
                lines.append(f"- **Note:** {s.inference_notes}")
            lines.append(f"- **Evidence:**")
            for e in s.evidence_chain[:2]:
                lines.append(f'  - `{e.source_file}` — "{e.raw_text[:100]}"')

    # Needs review
    low = [s for s in result.systems if s.confidence_tier == ConfidenceTier.LOW]
    if low:
        lines.append("\n## ⚠️  Requires Human Review (<70%)")
        for s in low:
            lines.append(f"\n### {s.name} `{s.confidence_score}%`")
            if s.review_reason:
                lines.append(f"- **Why flagged:** {s.review_reason}")
            if s.inference_notes:
                lines.append(f"- **What was inferred:** {s.inference_notes}")

    path = Path(output_dir) / "discovery_report.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return str(path)
