# Discovery Agent Report
*Generated: 2026-06-07 12:39*

## Summary
- Documents processed: **3**
- Systems discovered: **28**
- Requiring human review: **2**

> Discovery complete. Found 28 systems: 9 high-confidence, 17 medium-confidence, 2 requiring human review. Systems needing review: BI, CI/CD.

## High Confidence Systems (95%+)

### Coupa `100%`
- **Category:** Finance
- **Criticality:** unknown
- **Auth:** SAML SSO
- **Entities:** purchase orders
- **Processes:** procurement, spend management
- **Evidence (2 source(s)):**
  - `it_system_inventory.csv` — "Coupa"
  - `onboarding_wiki.md` — "- Coupa — Procurement and purchase orders."

### Expensify `100%`
- **Category:** Finance
- **Criticality:** medium
- **Entities:** expenses, Expense
- **Processes:** Expense reporting, expense reporting
- **Evidence (2 source(s)):**
  - `integration_audit.txt` — "Expensify → NetSuite"
  - `onboarding_wiki.md` — "- Expensify — Expense reporting."

### GitHub `100%`
- **Category:** DevOps
- **Criticality:** medium
- **Entities:** PR, source code repositories
- **Processes:** code management, Ticket creation, CI/CD pipelines
- **Evidence (3 source(s)):**
  - `integration_audit.txt` — "GitHub → Jira"
  - `it_system_inventory.csv` — "GitHub"
  - `onboarding_wiki.md` — "- GitHub — You'll be added to the engineering org."

### HubSpot `100%`
- **Category:** Other
- **Criticality:** unknown
- **Auth:** API Key
- **Entities:** Lead
- **Processes:** Lead sync, lead capture, email automation, marketing campaigns
- **Evidence (2 source(s)):**
  - `integration_audit.txt` — "HubSpot → Salesforce"
  - `it_system_inventory.csv` — "HubSpot"

### Jira `100%`
- **Category:** Project Management
- **Criticality:** unknown
- **Auth:** OAuth 2.0
- **Entities:** Ticket
- **Processes:** sprint planning, project management, bug tracking, Ticket management
- **Evidence (2 source(s)):**
  - `integration_audit.txt` — "GitHub → Jira"
  - `it_system_inventory.csv` — "Jira"

### NetSuite `100%`
- **Category:** ERP
- **Criticality:** high
- **Entities:** Sales Order, financial operations
- **Processes:** Expense sync, Order sync, procurement, invoicing, financial reporting, financial operations management
- **Evidence (3 source(s)):**
  - `integration_audit.txt` — "Salesforce → NetSuite"
  - `it_system_inventory.csv` — "NetSuite ERP"
  - `onboarding_wiki.md` — "- NetSuite — ERP for all financial operations."

### Salesforce `100%`
- **Category:** CRM
- **Criticality:** high
- **Entities:** contacts, Sales Order, customer data, leads, activity logs, opportunities, Lead, pipeline, Opportunity
- **Processes:** sales pipeline management, Order sync, sales engagement, Lead sync, customer database, customer relationship management
- **Evidence (3 source(s)):**
  - `integration_audit.txt` — "Salesforce → NetSuite"
  - `it_system_inventory.csv` — "Salesforce CRM"
  - `onboarding_wiki.md` — "- Salesforce — Our CRM."

### Workday `100%`
- **Category:** HRIS
- **Criticality:** unknown
- **Auth:** SAML SSO
- **Entities:** Headcount data, employee records
- **Processes:** Provisioning, performance reviews, payroll
- **Evidence (2 source(s)):**
  - `integration_audit.txt` — "No integration between Workday"
  - `it_system_inventory.csv` — "Workday"

### Zendesk `100%`
- **Category:** Other
- **Criticality:** medium
- **Entities:** Ticket, customer support tickets
- **Processes:** customer support ticket management, Ticket management
- **Evidence (2 source(s)):**
  - `integration_audit.txt` — "Zendesk → Slack"
  - `it_system_inventory.csv` — "Zendesk"

## Medium Confidence Systems (70–94%)

### Amazon Web Services `90%`
- **Category:** Storage
- **Note:** System inferred from references: AWS Lambda. Not explicitly named in source documents.
- **Evidence:**
  - `integration_audit.txt` — "hosted on AWS Lambda"
  - `it_system_inventory.csv` — "AWS"

### Okta `90%`
- **Category:** Identity & Auth
- **Note:** System inferred from references: Okta/Salesforce/GitHub. Not explicitly named in source documents.
- **Evidence:**
  - `integration_audit.txt` — "Workday → Okta"
  - `onboarding_wiki.md` — "- Okta — Single sign-on portal."

### Slack `90%`
- **Category:** Communication
- **Evidence:**
  - `integration_audit.txt` — "Zendesk → Slack"
  - `it_system_inventory.csv` — "Slack"

### Snowflake `90%`
- **Category:** Data Warehouse
- **Evidence:**
  - `integration_audit.txt` — "Snowflake ← multiple sources"
  - `it_system_inventory.csv` — "Snowflake"

### Tableau `90%`
- **Category:** Analytics
- **Evidence:**
  - `integration_audit.txt` — "Tableau connects to Snowflake"
  - `it_system_inventory.csv` — "Tableau"

### 1Password `85%`
- **Category:** Identity & Auth
- **Evidence:**
  - `onboarding_wiki.md` — "- 1Password — Password manager."

### Datadog `85%`
- **Category:** Analytics
- **Evidence:**
  - `onboarding_wiki.md` — "- Datadog — Application monitoring and logging."

### Google Workspace `85%`
- **Category:** Other
- **Evidence:**
  - `onboarding_wiki.md` — "- Google Workspace — Email (Gmail),"

### Stripe `85%`
- **Category:** Finance
- **Evidence:**
  - `integration_audit.txt` — "Stripe webhooks are consumed"

### AWS Lambda `75%`
- **Category:** Other
- **Evidence:**
  - `integration_audit.txt` — "hosted on AWS Lambda"

### Dbt `75%`
- **Category:** Other
- **Evidence:**
  - `integration_audit.txt` — "dbt transformations"

### Fivetran `75%`
- **Category:** Other
- **Evidence:**
  - `integration_audit.txt` — "Built on Fivetran"

### LinkedIn Sales Navigator `75%`
- **Category:** Other
- **Evidence:**
  - `onboarding_wiki.md` — "- LinkedIn Sales Navigator — Prospecting tool,"

### Outreach `75%`
- **Category:** Other
- **Evidence:**
  - `onboarding_wiki.md` — "- Outreach — Sales engagement platform"

### PagerDuty `75%`
- **Category:** Other
- **Evidence:**
  - `onboarding_wiki.md` — "- PagerDuty — On-call rotation management."

### ServiceNow `75%`
- **Category:** Other
- **Evidence:**
  - `onboarding_wiki.md` — "Submit an IT ticket via our helpdesk (ServiceNow)"

### Zapier `75%`
- **Category:** Other
- **Evidence:**
  - `integration_audit.txt` — "Sync runs every 30 minutes via Zapier"

## ⚠️  Requires Human Review (<70%)

### BI `0%`
- **Why flagged:** Confidence 0% is below 70% threshold. 1 of 1 mentions could not be verified in source text.
- **What was inferred:** System inferred from references: BI dashboards. Not explicitly named in source documents.

### CI/CD `0%`
- **Why flagged:** Confidence 0% is below 70% threshold. 1 of 1 mentions could not be verified in source text.
- **What was inferred:** System inferred from references: CI/CD pipelines. Not explicitly named in source documents.