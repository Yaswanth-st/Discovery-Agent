# Discovery Agent Report
*Generated: 2026-06-08 09:13*

## Summary
- Documents processed: **2**
- Systems discovered: **15**
- Requiring human review: **1**
- Audit log: `C:\Users\yaswa\Downloads\Aivar trials\Level 1\discovery_agent\discovery_agent\output\ui\audit_log.jsonl`

> Discovery complete. Found 15 systems: 0 high-confidence, 14 medium-confidence, 1 requiring human review. Systems needing review: Google Workspace.


## Medium Confidence Systems (70–94%)

### Coupa `75%`
- **Category:** Finance
- **Evidence:**
  - `systems_inventory.csv` — "Row 12: Coupa | Procurement | OAuth 2.0 | Finance | Medium | Vendor invoice management."
  - `integration_gaps.txt` — "CRITICAL GAPS

Gap 1: Coupa to NetSuite (CRITICAL)
Finance exports vendor invoices from Coupa as a C"

### Datadog `75%`
- **Category:** DevOps
- **Evidence:**
  - `systems_inventory.csv` — "Row 8: Datadog | Monitoring | API Key | Platform | High | APM and infrastructure monitoring."
  - `integration_gaps.txt` — "EXISTING INTEGRATIONS (working)
- Okta SSO to Salesforce, GitHub, Jira, Slack, Google Workspace — op"

### GitHub `75%`
- **Category:** DevOps
- **Evidence:**
  - `systems_inventory.csv` — "Row 7: GitHub | DevOps | OAuth App | Engineering | High | Source code and CI/CD pipelines."
  - `integration_gaps.txt` — "EXISTING INTEGRATIONS (working)
- Okta SSO to Salesforce, GitHub, Jira, Slack, Google Workspace — op"

### HubSpot `75%`
- **Category:** Marketing Automation
- **Evidence:**
  - `systems_inventory.csv` — "Row 11: HubSpot | Marketing | OAuth 2.0 | Marketing | Medium | Inbound leads."
  - `integration_gaps.txt` — "EXISTING INTEGRATIONS (working)
- Okta SSO to Salesforce, GitHub, Jira, Slack, Google Workspace — op"

### Jira `75%`
- **Category:** Project Management
- **Evidence:**
  - `systems_inventory.csv` — "Row 16: Jira | Project Management | API Token | Engineering | Medium | Sprint planning and bug track"
  - `integration_gaps.txt` — "EXISTING INTEGRATIONS (working)
- Okta SSO to Salesforce, GitHub, Jira, Slack, Google Workspace — op"

### NetSuite `75%`
- **Category:** ERP
- **Evidence:**
  - `systems_inventory.csv` — "Row 3: NetSuite | ERP | OAuth 1.0a | Finance | Critical | All invoicing and GL reporting."
  - `integration_gaps.txt` — "CRITICAL GAPS

Gap 1: Coupa to NetSuite (CRITICAL)
Finance exports vendor invoices from Coupa as a C"

### Okta `75%`
- **Category:** Identity & Auth
- **Evidence:**
  - `systems_inventory.csv` — "Row 5: Okta | Identity & Auth | SAML/OIDC | IT | Critical | SSO provider for all SaaS apps."
  - `integration_gaps.txt` — "Gap 4: Workday to Okta (MEDIUM)
New employee provisioning requires HR to email IT after creating the"

### PagerDuty `75%`
- **Category:** DevOps
- **Evidence:**
  - `systems_inventory.csv` — "Row 15: PagerDuty | Monitoring | API Key | Platform | High | On-call alerting from Datadog."
  - `integration_gaps.txt` — "EXISTING INTEGRATIONS (working)
- Okta SSO to Salesforce, GitHub, Jira, Slack, Google Workspace — op"

### Salesforce `75%`
- **Category:** CRM
- **Evidence:**
  - `systems_inventory.csv` — "Row 1: System Name | Category | Auth Method | Owner | Criticality | Notes
Row 2: Salesforce | CRM | "
  - `integration_gaps.txt` — "Gap 3: Zendesk to Salesforce (HIGH)
Customer Success Managers manually copy ticket resolutions into "

### Slack `75%`
- **Category:** Communication
- **Evidence:**
  - `systems_inventory.csv` — "Row 14: Slack | Communication | OAuth 2.0 | All Teams | High | Primary chat and notifications."
  - `integration_gaps.txt` — "IT then manually creates Okta, Slack, and Google Workspace accounts."

### Snowflake `75%`
- **Category:** Data Warehouse
- **Evidence:**
  - `systems_inventory.csv` — "Row 6: Snowflake | Data Warehouse | Key Pair Auth | Data Team | High | Central analytics warehouse."
  - `integration_gaps.txt` — "EXISTING INTEGRATIONS (working)
- Okta SSO to Salesforce, GitHub, Jira, Slack, Google Workspace — op"

### Stripe `75%`
- **Category:** Finance
- **Evidence:**
  - `systems_inventory.csv` — "Row 9: Stripe | Payments | API Key | Finance/Engineering | Critical | Payment processing."
  - `integration_gaps.txt` — "Gap 2: Stripe to NetSuite (HIGH)
Stripe webhook events are reconciled to NetSuite revenue entries ma"

### Workday `75%`
- **Category:** HRIS
- **Evidence:**
  - `systems_inventory.csv` — "Row 4: Workday | HRIS | SAML 2.0 | HR | High | HR system of record for all employees."
  - `integration_gaps.txt` — "Gap 4: Workday to Okta (MEDIUM)
New employee provisioning requires HR to email IT after creating the"

### Zendesk `75%`
- **Category:** Customer Support
- **Evidence:**
  - `systems_inventory.csv` — "Row 10: Zendesk | Support | API Token | Support Team | High | Customer support ticketing."
  - `integration_gaps.txt` — "Gap 3: Zendesk to Salesforce (HIGH)
Customer Success Managers manually copy ticket resolutions into "

## ⚠️  Requires Human Review (<70%)

### Google Workspace `60%`
- **Why flagged:** Confidence 60% is below 70% threshold. 0 of 1 mentions could not be verified in source text.