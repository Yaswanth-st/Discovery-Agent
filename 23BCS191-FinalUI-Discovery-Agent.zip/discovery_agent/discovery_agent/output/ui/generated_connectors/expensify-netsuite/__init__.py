"""Generated connector package."""
