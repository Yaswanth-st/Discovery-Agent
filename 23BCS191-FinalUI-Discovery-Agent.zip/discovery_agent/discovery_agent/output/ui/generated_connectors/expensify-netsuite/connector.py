"""Generated connector for Expensify to NetSuite."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Iterable, Optional

import requests

logger = logging.getLogger(__name__)


class ConnectorError(RuntimeError):
    """Raised when the connector cannot complete a request."""


@dataclass
class ConnectorConfig:
    base_url: str
    auth_mode: str = "bearer"
    api_key: Optional[str] = None
    bearer_token: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    timeout_seconds: int = 30
    max_retries: int = 3
    backoff_factor: float = 0.5


class ExpensifyNetsuite:
    """Generic production-shaped connector for Expensify → NetSuite."""

    def __init__(self, config: ConnectorConfig, session: Optional[requests.Session] = None):
        self.config = config
        self.session = session or requests.Session()
        self.session.headers.update(self._build_headers())

    def _build_headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if self.config.auth_mode == "bearer" and self.config.bearer_token:
            headers["Authorization"] = f"Bearer {self.config.bearer_token}"
        elif self.config.auth_mode == "api_key" and self.config.api_key:
            headers["X-API-Key"] = self.config.api_key
        return headers

    def _request(self, method: str, path: str, *, params: Optional[dict[str, Any]] = None, json_body: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        url = f"{self.config.base_url.rstrip('/') }/{path.lstrip('/')}"
        last_error: Exception | None = None

        for attempt in range(self.config.max_retries):
            try:
                logger.info("connector_request", extra={"method": method, "url": url, "attempt": attempt + 1})
                response = self.session.request(
                    method,
                    url,
                    params=params,
                    json=json_body,
                    timeout=self.config.timeout_seconds,
                )
                if response.status_code == 429 or response.status_code >= 500:
                    raise ConnectorError(f"Transient HTTP {response.status_code} from {url}")
                response.raise_for_status()
                if not response.content:
                    return {}
                return response.json()
            except Exception as exc:  # pragma: no cover - exercised by generated package tests
                last_error = exc
                if attempt + 1 < self.config.max_retries:
                    sleep_for = self.config.backoff_factor * (2 ** attempt)
                    time.sleep(sleep_for)
                    continue
                raise ConnectorError(f"Failed {method} {url} after {self.config.max_retries} attempts: {exc}") from exc

        raise ConnectorError(f"Failed {method} {url}: {last_error}")

    def list_resources(
        self,
        path: str,
        *,
        cursor_param: str = "page",
        next_cursor_key: str = "next_cursor",
        items_key: str = "items",
    ) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        cursor: Any = 1

        while cursor is not None:
            payload = self._request("GET", path, params={cursor_param: cursor})
            items.extend(payload.get(items_key, []))
            cursor = payload.get(next_cursor_key)
        return items

    def get_resource(self, path: str, resource_id: str) -> dict[str, Any]:
        return self._request("GET", f"{path.rstrip('/') }/{resource_id}")

    def create_resource(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", path, json_body=payload)

    def update_resource(self, path: str, resource_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("PATCH", f"{path.rstrip('/') }/{resource_id}", json_body=payload)

    def delete_resource(self, path: str, resource_id: str) -> dict[str, Any]:
        return self._request("DELETE", f"{path.rstrip('/') }/{resource_id}")


__all__ = ["ConnectorConfig", "ConnectorError", "ExpensifyNetsuite"]
