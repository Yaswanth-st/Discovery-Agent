"""Generated connector tests."""

import os
import sys
from pathlib import Path
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from connector import ConnectorConfig, GithubJira


class ConnectorTests(unittest.TestCase):
    def setUp(self):
        self.session = Mock()
        self.connector = GithubJira(
            ConnectorConfig(base_url="https://example.com", bearer_token="token"),
            session=self.session,
        )

    def _response(self, status_code=200, payload=None):
        response = Mock()
        response.status_code = status_code
        response.content = b"1"
        response.json.return_value = payload or {}
        response.raise_for_status.return_value = None
        return response

    def test_get_resource(self):
        self.session.request.return_value = self._response(payload={"id": "123"})
        result = self.connector.get_resource("/objects", "123")
        self.assertEqual(result["id"], "123")

    def test_create_resource(self):
        self.session.request.return_value = self._response(payload={"id": "abc"})
        result = self.connector.create_resource("/objects", {"name": "Demo"})
        self.assertEqual(result["id"], "abc")

    def test_pagination(self):
        first = self._response(payload={"items": [{"id": 1}], "next_cursor": 2})
        second = self._response(payload={"items": [{"id": 2}], "next_cursor": None})
        self.session.request.side_effect = [first, second]
        items = self.connector.list_resources("/objects")
        self.assertEqual([item["id"] for item in items], [1, 2])

    @patch("connector.time.sleep", return_value=None)
    def test_retries_transient_errors(self, _sleep):
        first = self._response(status_code=429, payload={})
        second = self._response(payload={"ok": True})
        self.session.request.side_effect = [first, second]
        result = self.connector.get_resource("/objects", "123")
        self.assertTrue(result["ok"])


if __name__ == "__main__":
    unittest.main()
