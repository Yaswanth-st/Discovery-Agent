# github-jira

Generated connector for GitHub → Jira.

## What it includes
- Authentication handling
- CRUD helpers
- Pagination support
- Retry with exponential backoff
- Tests for the generated connector

## Setup
```bash
pip install -r requirements.txt
```

Set the following environment variables before running the connector:
- `BASE_URL`
- `BEARER_TOKEN` or `API_KEY`

## Run tests
```bash
python -m unittest discover -s tests
```
