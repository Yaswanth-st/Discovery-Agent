"""Level 2: map business use cases to discovered systems and find integration gaps.

The goal is to be deterministic and auditable first. The analyzer prefers
explicit evidence from the input text and falls back to conservative heuristics
when the wording is incomplete.
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass
from itertools import combinations
from typing import Iterable

from models import DiscoveredSystem, GapAnalysisResult, IntegrationGap, UseCaseMapping, UseCaseType


ENTITY_HINTS: list[tuple[str, str]] = [
    ("lead", "Lead"),
    ("customer", "Customer"),
    ("order", "Order"),
    ("invoice", "Invoice"),
    ("expense", "Expense"),
    ("ticket", "Ticket"),
    ("employee", "Employee"),
    ("hire", "Employee"),
    ("pull request", "Pull Request"),
    ("pr", "Pull Request"),
    ("repository", "Repository"),
    ("report", "Report"),
    ("payment", "Payment"),
    ("revenue", "Revenue"),
]

FREQUENCY_PATTERNS: list[tuple[re.Pattern[str], int]] = [
    (re.compile(r"\bdaily\b", re.I), 30),
    (re.compile(r"\bweekly\b", re.I), 4),
    (re.compile(r"\bmonthly\b", re.I), 1),
    (re.compile(r"every\s+(\d+)\s+hours?", re.I), 24),
    (re.compile(r"(\d+)\s+times\s+a\s+year", re.I), 0),
    (re.compile(r"(\d+)\s+times\s+a\s+month", re.I), 1),
    (re.compile(r"(\d+)\s+times\s+a\s+week", re.I), 4),
    (re.compile(r"(\d+)\s+hours?/month", re.I), 1),
]

TRIGGER_HINTS: list[tuple[str, str]] = [
    ("when a new hire", "New hire created"),
    ("when an opportunity", "Opportunity status changed"),
    ("when a lead", "Lead created or updated"),
    ("when an order", "Order created"),
    ("nightly", "Nightly batch"),
    ("manual", "Manual request"),
    ("webhook", "Webhook event"),
    ("sync", "Scheduled sync"),
    ("closed won", "Deal closed-won"),
]

USE_CASE_TYPE_HINTS: list[tuple[str, UseCaseType]] = [
    ("onboard", UseCaseType.ONBOARDING),
    ("hire", UseCaseType.ONBOARDING),
    ("expense", UseCaseType.FINANCE),
    ("invoice", UseCaseType.FINANCE),
    ("payment", UseCaseType.FINANCE),
    ("lead", UseCaseType.SALES),
    ("customer", UseCaseType.SALES),
    ("ticket", UseCaseType.SUPPORT),
    ("pull request", UseCaseType.ENGINEERING),
    ("repo", UseCaseType.ENGINEERING),
    ("marketing", UseCaseType.MARKETING),
    ("reporting", UseCaseType.DATA),
    ("warehouse", UseCaseType.DATA),
]


@dataclass(frozen=True)
class _IntegrationFact:
    source_system: str
    destination_system: str
    evidence: str


def analyze_gaps(
    systems: list[DiscoveredSystem],
    automation_goals_text: str,
    existing_integrations_text: str = "",
) -> GapAnalysisResult:
    """Analyze automation goals against a discovered system inventory."""
    system_lookup = _build_system_lookup(systems)
    existing_integrations = _parse_existing_integrations(existing_integrations_text, system_lookup)
    use_case_lines = _split_use_case_lines(automation_goals_text)

    use_cases: list[UseCaseMapping] = []
    gap_map: dict[tuple[str, str, str], IntegrationGap] = {}
    gap_usage: defaultdict[tuple[str, str], list[str]] = defaultdict(list)

    for index, line in enumerate(use_case_lines, start=1):
        mapping = _map_use_case(line, system_lookup, systems)
        if not mapping:
            continue

        use_case_title = _title_from_text(line, index)
        use_case_type = _infer_use_case_type(line)
        involved_systems = mapping["systems"]
        source_system = mapping["source_system"]
        destination_system = mapping["destination_system"]
        entity_type = mapping["entity_type"]
        trigger_event = mapping["trigger_event"]
        existing_integration = mapping["existing_integration"]
        confidence_score = mapping["confidence_score"]
        frequency_per_month = _infer_frequency(line)
        business_impact = _infer_business_impact(line, frequency_per_month, involved_systems)

        use_cases.append(
            UseCaseMapping(
                title=use_case_title,
                description=line,
                use_case_type=use_case_type,
                involved_systems=involved_systems,
                source_system=source_system,
                destination_system=destination_system,
                entity_type=entity_type,
                trigger_event=trigger_event,
                existing_integration=existing_integration,
                confidence_score=confidence_score,
                frequency_per_month=frequency_per_month,
                business_impact=business_impact,
                notes=mapping["notes"],
            )
        )

        for source_name, destination_name in _pairwise_connections(source_system, destination_system, involved_systems):
            pair_key = (source_name, destination_name)
            gap_usage[pair_key].append(use_case_title)
            if _integration_is_existing(source_name, destination_name, existing_integrations):
                continue

            gap_key = (source_name, destination_name, use_case_title)
            if gap_key not in gap_map:
                gap_map[gap_key] = _build_gap(
                    source_name,
                    destination_name,
                    use_case_title,
                    entity_type,
                    trigger_event,
                    line,
                    systems,
                    frequency_per_month,
                    business_impact,
                )

    gaps = list(gap_map.values())
    gaps.sort(key=lambda gap: (-gap.priority_score, gap.source_system, gap.destination_system))
    summary = _build_summary(use_cases, gaps, systems)

    return GapAnalysisResult(
        total_use_cases=len(use_case_lines),
        mapped_use_cases=len(use_cases),
        total_gaps=len(gaps),
        systems_in_scope=len(systems),
        use_cases=use_cases,
        gaps=gaps,
        summary=summary,
    )


def _build_system_lookup(systems: Iterable[DiscoveredSystem]) -> dict[str, DiscoveredSystem]:
    lookup: dict[str, DiscoveredSystem] = {}
    for system in systems:
        lookup[system.name.lower()] = system
        for alias in system.aliases:
            lookup[alias.lower()] = system
    return lookup


def _split_use_case_lines(text: str) -> list[str]:
    lines: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip().lstrip("-•*0123456789. ").strip()
        if len(line) < 12:
            continue
        if line.startswith("#"):
            continue
        lines.append(line)

    if lines:
        return lines

    # Fallback: split paragraphs into usable chunks.
    chunks = [chunk.strip() for chunk in re.split(r"\n\s*\n", text) if len(chunk.strip()) > 20]
    return chunks or [text.strip()]


def _map_use_case(
    text: str,
    system_lookup: dict[str, DiscoveredSystem],
    systems: list[DiscoveredSystem],
) -> dict[str, object] | None:
    normalized = text.lower()
    matched_systems = _match_systems(normalized, system_lookup)
    matched_systems = _augment_common_systems(normalized, matched_systems, system_lookup)

    if not matched_systems:
        return None

    source_system, destination_system = _infer_direction(text, matched_systems)
    entity_type = _infer_entity_type(normalized)
    trigger_event = _infer_trigger(normalized)
    confidence_score = _confidence_for_mapping(text, matched_systems, source_system, destination_system)
    notes = _build_notes(text, matched_systems, source_system, destination_system, confidence_score)
    existing_integration = _has_existing_integration_language(normalized)

    return {
        "systems": matched_systems,
        "source_system": source_system,
        "destination_system": destination_system,
        "entity_type": entity_type,
        "trigger_event": trigger_event,
        "confidence_score": confidence_score,
        "notes": notes,
        "existing_integration": existing_integration,
    }


def _match_systems(text: str, system_lookup: dict[str, DiscoveredSystem]) -> list[str]:
    matched: list[str] = []
    used = set()
    # Match longer aliases first so "Google Workspace" wins before "Google"-like fragments.
    for alias in sorted(system_lookup.keys(), key=len, reverse=True):
        pattern = rf"(?<!\w){re.escape(alias)}(?!\w)"
        if re.search(pattern, text, re.I):
            system_name = system_lookup[alias].name
            if system_name not in used:
                used.add(system_name)
                matched.append(system_name)
    return matched


def _augment_common_systems(
    text: str,
    matched_systems: list[str],
    system_lookup: dict[str, DiscoveredSystem],
) -> list[str]:
    augmented = list(matched_systems)

    common_sources = [
        ("onboard", "Workday"),
        ("new hire", "Workday"),
        ("expense", "Expensify"),
        ("lead", "HubSpot"),
        ("pull request", "GitHub"),
        ("pr", "GitHub"),
        ("revenue recognition", "Stripe"),
    ]

    for keyword, system_name in common_sources:
        if keyword in text and any(existing.name == system_name for existing in system_lookup.values()):
            if system_name not in augmented:
                augmented.insert(0, system_name)

    # Ensure common destinations are present for common workflows.
    common_destinations = ["Okta", "NetSuite", "Salesforce", "Jira", "Snowflake"]
    for system_name in common_destinations:
        if any(existing.name == system_name for existing in system_lookup.values()) and system_name.lower() in text and system_name not in augmented:
            augmented.append(system_name)

    # Deduplicate while preserving order.
    deduped: list[str] = []
    for system_name in augmented:
        if system_name not in deduped:
            deduped.append(system_name)
    return deduped


def _infer_direction(text: str, matched_systems: list[str]) -> tuple[str, str]:
    if len(matched_systems) == 1:
        return matched_systems[0], matched_systems[0]

    lower = text.lower()

    if any(keyword in lower for keyword in ("new hire", "onboard", "onboarding")) and "Workday" in matched_systems:
        destination_candidates = [system for system in matched_systems if system != "Workday"]
        if destination_candidates:
            return "Workday", destination_candidates[0]

    if "expense" in lower and "Expensify" in matched_systems and "NetSuite" in matched_systems:
        return "Expensify", "NetSuite"

    if "lead" in lower and "HubSpot" in matched_systems and "Salesforce" in matched_systems:
        return "HubSpot", "Salesforce"

    if ("pull request" in lower or re.search(r"\bpr\b", lower)) and "GitHub" in matched_systems and "Jira" in matched_systems:
        return "GitHub", "Jira"

    if "revenue recognition" in lower and "Stripe" in matched_systems and "NetSuite" in matched_systems:
        return "Stripe", "NetSuite"

    arrow_match = re.search(r"([A-Za-z0-9 &+./-]+)\s*(?:→|->|to|into|into the)\s*([A-Za-z0-9 &+./-]+)", lower)
    if arrow_match:
        source = _best_system_from_fragment(arrow_match.group(1), matched_systems) or matched_systems[0]
        destination = _best_system_from_fragment(arrow_match.group(2), matched_systems) or matched_systems[-1]
        return source, destination

    if "from" in lower and "to" in lower:
        from_part = lower.split("from", 1)[1].split("to", 1)[0]
        to_part = lower.split("to", 1)[1]
        source = _best_system_from_fragment(from_part, matched_systems) or matched_systems[0]
        destination = _best_system_from_fragment(to_part, matched_systems) or matched_systems[-1]
        return source, destination

    return matched_systems[0], matched_systems[-1]


def _best_system_from_fragment(fragment: str, matched_systems: list[str]) -> str | None:
    fragment = fragment.lower()
    for system_name in matched_systems:
        if system_name.lower() in fragment:
            return system_name
    return None


def _infer_entity_type(text: str) -> str:
    for keyword, entity in ENTITY_HINTS:
        if keyword in text:
            return entity
    return "Business Record"


def _infer_trigger(text: str) -> str:
    for keyword, trigger in TRIGGER_HINTS:
        if keyword in text:
            return trigger
    return "Business event"


def _infer_use_case_type(text: str) -> UseCaseType:
    for keyword, case_type in USE_CASE_TYPE_HINTS:
        if keyword in text.lower():
            return case_type
    return UseCaseType.OTHER


def _infer_frequency(text: str) -> int | None:
    lower = text.lower()
    for pattern, default_value in FREQUENCY_PATTERNS:
        match = pattern.search(lower)
        if not match:
            continue
        if match.lastindex:
            if "hours" in pattern.pattern:
                hours = int(match.group(1))
                return max(1, int(round((24 / max(hours, 1)) * 30)))
            if "times a year" in pattern.pattern:
                return max(1, int(round(int(match.group(1)) / 12)))
            if "times a month" in pattern.pattern:
                return int(match.group(1))
            if "times a week" in pattern.pattern:
                return int(match.group(1)) * 4
        return default_value
    return None


def _infer_business_impact(text: str, frequency_per_month: int | None, systems: list[str]) -> str:
    score = 0
    lower = text.lower()
    if frequency_per_month:
        score += 2 if frequency_per_month >= 30 else 1
    if any(keyword in lower for keyword in ("critical", "high priority", "saves", "manual", "hour", "block")):
        score += 2
    if len(systems) >= 3:
        score += 1

    if score >= 4:
        return "high"
    if score >= 2:
        return "medium"
    return "low"


def _confidence_for_mapping(text: str, matched_systems: list[str], source_system: str, destination_system: str) -> int:
    score = 40
    score += min(len(matched_systems) * 15, 30)
    if source_system != destination_system:
        score += 10
    if any(marker in text.lower() for marker in ["to", "from", "into", "sync", "integrat", "webhook", "api"]):
        score += 10
    if len(text.split()) > 12:
        score += 10
    return max(40, min(100, score))


def _build_notes(text: str, matched_systems: list[str], source_system: str, destination_system: str, confidence_score: int) -> str:
    if confidence_score >= 80:
        return f"Strong evidence for {', '.join(matched_systems)} in source text."
    return (
        f"Evidence suggests {', '.join(matched_systems)} are involved, but direction was inferred "
        f"as {source_system} → {destination_system}."
    )


def _has_existing_integration_language(text: str) -> bool:
    return any(
        keyword in text
        for keyword in ("integrated", "integration", "sync", "syncs", "connected", "native integration", "already exists")
    )


def _pairwise_connections(source_system: str, destination_system: str, involved_systems: list[str]) -> list[tuple[str, str]]:
    if source_system == destination_system:
        return []
    if source_system and destination_system:
        if len(involved_systems) > 2:
            return [(source_system, target) for target in involved_systems if target != source_system]
        return [(source_system, destination_system)]
    if len(involved_systems) < 2:
        return []
    return list(combinations(involved_systems, 2))


def _parse_existing_integrations(
    text: str,
    system_lookup: dict[str, DiscoveredSystem],
) -> list[_IntegrationFact]:
    facts: list[_IntegrationFact] = []
    if not text.strip():
        return facts

    in_gap_section = False
    for line in text.splitlines():
        line = line.strip().lstrip("-•*0123456789. ").strip()
        if not line:
            continue

        upper = line.upper()
        if "GAPS IDENTIFIED" in upper or "GAP" in upper and "IDENTIFIED" in upper:
            in_gap_section = True
            continue

        if in_gap_section:
            continue

        lowered = line.lower()
        if any(keyword in lowered for keyword in ("manual", "missing", "no integration", "not automated", "gap")):
            continue

        systems = _match_systems(line.lower(), system_lookup)
        if len(systems) >= 2:
            source, destination = _infer_direction(line, systems)
            facts.append(_IntegrationFact(source, destination, line))

    return facts


def _integration_is_existing(source: str, destination: str, facts: list[_IntegrationFact]) -> bool:
    for fact in facts:
        if fact.source_system == source and fact.destination_system == destination:
            return True
        if fact.source_system == destination and fact.destination_system == source:
            return True
    return False


def _build_gap(
    source_system: str,
    destination_system: str,
    use_case_title: str,
    entity_type: str,
    trigger_event: str,
    description: str,
    systems: list[DiscoveredSystem],
    frequency_per_month: int | None,
    business_impact: str,
) -> IntegrationGap:
    source_criticality = _system_criticality_weight(source_system, systems)
    destination_criticality = _system_criticality_weight(destination_system, systems)
    frequency_weight = 30 if frequency_per_month and frequency_per_month >= 30 else 20 if frequency_per_month else 10
    priority_score = min(100, source_criticality + destination_criticality + frequency_weight)
    estimated_effort = _estimate_effort(description)
    recommendation = (
        f"Build an authenticated {source_system} → {destination_system} connector for {entity_type.lower()} events."
    )
    return IntegrationGap(
        gap_id=f"{source_system.lower()}-{destination_system.lower()}-{abs(hash(use_case_title)) % 10000}",
        source_system=source_system,
        destination_system=destination_system,
        use_case_title=use_case_title,
        entity_type=entity_type,
        trigger_event=trigger_event,
        current_state="No verified integration found in source materials.",
        missing_capability=f"Automated transfer of {entity_type.lower()} data from {source_system} to {destination_system}",
        priority_score=priority_score,
        estimated_effort=estimated_effort,
        confidence_score=min(100, 70 + (10 if frequency_per_month else 0) + (10 if business_impact == 'high' else 0)),
        business_value=business_impact,
        recommendation=recommendation,
        related_use_cases=[use_case_title],
    )


def _estimate_effort(description: str) -> str:
    lower = description.lower()
    if any(keyword in lower for keyword in ("manual", "csv", "copy-paste", "native integration")):
        return "Low to Medium"
    if any(keyword in lower for keyword in ("non-standard auth", "pagination", "retry", "webhook")):
        return "Medium"
    return "Medium"


def _system_criticality_weight(name: str, systems: list[DiscoveredSystem]) -> int:
    for system in systems:
        if system.name == name:
            criticality = system.criticality.value if system.criticality else "unknown"
            return {"high": 35, "medium": 20, "low": 10, "unknown": 15}.get(criticality, 15)
    return 15


def _build_summary(use_cases: list[UseCaseMapping], gaps: list[IntegrationGap], systems: list[DiscoveredSystem]) -> str:
    high_priority = sum(1 for gap in gaps if gap.priority_score >= 70)
    return (
        f"Mapped {len(use_cases)} use case(s) across {len(systems)} systems and identified {len(gaps)} gap(s); "
        f"{high_priority} gap(s) are high priority."
    )


def _title_from_text(text: str, index: int) -> str:
    head = re.split(r"[\.:;\-]", text, maxsplit=1)[0].strip()
    if len(head.split()) >= 2:
        return head[:80]
    return f"Use case {index}"


def _build_connection_matrix(gaps: list[IntegrationGap]) -> dict[str, list[str]]:
    matrix: dict[str, list[str]] = defaultdict(list)
    for gap in gaps:
        matrix[gap.source_system].append(gap.destination_system)
    return dict(matrix)
