# Discovery Agent

An autonomous AI agent that reads mixed-format business documents and produces a verified, confidence-scored inventory of every software system in use — with full evidence chains and zero hallucinations.

## Architecture

```
Documents (PDF, image, text, spreadsheet, HTML)
    ↓
Format Router → specialist parser per file type
    ↓
Multi-Pass Extractor (3 focused LLM calls per document)
    Pass 1: Explicitly named systems
    Pass 2: Implied / inferred systems
    Pass 3: Evidence verification (hallucination guard)
    ↓
Rules-Based Confidence Scorer (not LLM-assigned)
    ↓
Deduplication + Alias Resolution
    ↓
JSON output + Markdown report
```

**Key design decision:** Confidence is computed from evidence rules, not from what the LLM claims. The LLM is used to extract and cite; the rules engine decides how much to trust each finding.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Add your ANTHROPIC_API_KEY to .env
```

For image OCR, install Tesseract:
- Ubuntu/Debian: `sudo apt-get install tesseract-ocr`
- macOS: `brew install tesseract`

## Usage

```bash
python main.py --docs ./sample_docs --output ./output
python main.py --interactive --docs ./sample_docs --output ./output
streamlit run app.py
```

Interactive mode adds a small terminal UI for demoing the pipeline, previewing source documents, and rerunning discovery without editing code.
The Streamlit app provides the full Level 1, 2, and 3 workflow in one place with persistence and artifact downloads.

## Output

- `output/discovery_result.json` — structured JSON, one entry per system
- `output/discovery_report.md` — human-readable report with evidence citations
- `output/audit_log.jsonl` — structured event trail for document loading, extraction, verification, and scoring
- `output/ui/discovery_agent.sqlite3` — persistent history for Level 1, 2, and 3 runs

## Running Tests

```bash
python tests/test_validator.py
```

Tests cover confidence scoring, alias resolution, and hallucination detection — no API key required.
The suite now also includes a real PDF text-extraction check using a generated PDF fixture.

## Confidence Scoring Rules

| Signal | Points |
|---|---|
| Verified quote found in source | +40 |
| Explicit naming (not inferred) | +20 |
| Found in multiple documents | +15 |
| Key entities identified | +10 |
| Business processes identified | +10 |
| Criticality stated | +5 |
| Inferred with no verification | -20 |
| Zero verified mentions | -10 |

Systems below 70% are flagged for human review with an explanation of what was inferred and what evidence was missing.
