"""Tests for Level 2 gap analysis."""

import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from gap_analysis import analyze_gaps
from models import (
    Criticality,
    ConfidenceTier,
    DiscoveredSystem,
    EvidenceItem,
    SystemCategory,
)

ROOT = Path(__file__).resolve().parents[1]


def _system(name: str, category: SystemCategory, aliases=None, criticality=Criticality.HIGH):
    return DiscoveredSystem(
        name=name,
        aliases=aliases or [],
        category=category,
        auth_method="OAuth 2.0",
        key_entities=[name],
        business_processes=[f"{name} workflow"],
        criticality=criticality,
        confidence_score=98,
        confidence_tier=ConfidenceTier.HIGH,
        evidence_chain=[
            EvidenceItem(
                source_file="sample.md",
                location="p.1",
                raw_text=f"{name} is used across the business.",
                extraction_method="explicit",
            )
        ],
        inference_notes=None,
        human_review_required=False,
        review_reason=None,
    )


def test_gap_analysis_finds_key_missing_integrations():
    inventory = [
        _system("Workday", SystemCategory.ERP),
        _system("Okta", SystemCategory.IDENTITY),
        _system("Slack", SystemCategory.COMMUNICATION),
        _system("Google Workspace", SystemCategory.COMMUNICATION),
        _system("GitHub", SystemCategory.DEVOPS),
        _system("AWS", SystemCategory.CLOUD_PLATFORM),
        _system("NetSuite", SystemCategory.ERP),
        _system("Expensify", SystemCategory.FINANCE),
        _system("Jira", SystemCategory.PROJECT_MANAGEMENT),
        _system("HubSpot", SystemCategory.MARKETING_AUTOMATION),
        _system("Salesforce", SystemCategory.CRM, aliases=["SFDC"]),
        _system("Stripe", SystemCategory.FINANCE),
        _system("Snowflake", SystemCategory.DATA_WAREHOUSE),
    ]

    goals_text = (ROOT / "sample_docs" / "automation_goals.md").read_text(encoding="utf-8")
    result = analyze_gaps(inventory, goals_text, (ROOT / "sample_docs" / "integration_audit.txt").read_text(encoding="utf-8"))

    assert result.mapped_use_cases >= 4
    assert any(gap.source_system == "Workday" and gap.destination_system == "Okta" for gap in result.gaps)
    assert any(gap.source_system == "Expensify" and gap.destination_system == "NetSuite" for gap in result.gaps)
    assert any(gap.source_system == "GitHub" and gap.destination_system == "Jira" for gap in result.gaps)
    assert result.summary


if __name__ == "__main__":
    test_gap_analysis_finds_key_missing_integrations()
    print("Level 2 gap analysis test passed")