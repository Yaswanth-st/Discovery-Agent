"""
Unit tests for the confidence scorer and validator.
These run without an API key — they test our rules-based logic.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from extractor.extractor import RawSystemCandidate, _quote_exists_in_text
from validator.validator import _compute_confidence, _resolve_canonical_name, _normalize_category


def test_confidence_high_explicit_verified():
    """A verified, explicitly named system in multiple docs should score high."""
    candidates = [
        RawSystemCandidate(
            name="Salesforce", source_file="doc1.pdf",
            source_location="p.1", extraction_type="explicit",
            raw_evidence_quote="Sales team uses Salesforce daily",
            verified=True, key_entities=["Leads", "Contacts"],
            business_processes=["Pipeline management"],
            criticality="high"
        ),
        RawSystemCandidate(
            name="Salesforce", source_file="doc2.md",
            source_location="section 2", extraction_type="explicit",
            raw_evidence_quote="SFDC is our CRM",
            verified=True, key_entities=["Opportunities"],
            business_processes=[], criticality="high"
        ),
    ]
    score = _compute_confidence(candidates, {"doc1.pdf", "doc2.md"}, [])
    assert score >= 95, f"Expected >=95, got {score}"
    print(f"  PASS: high confidence = {score}")


def test_confidence_low_inferred_unverified():
    """An inferred, unverified system should score below 70."""
    candidates = [
        RawSystemCandidate(
            name="SomeSystem", source_file="doc1.txt",
            source_location="p.3", extraction_type="inferred",
            raw_evidence_quote="", verified=False,
            key_entities=[], business_processes=[], criticality="unknown"
        ),
    ]
    score = _compute_confidence(candidates, {"doc1.txt"}, [])
    assert score < 70, f"Expected <70, got {score}"
    print(f"  PASS: low confidence = {score}")


def test_confidence_medium_explicit_not_verified():
    """Explicitly named but quote not verified — should score above 0 but below high."""
    candidates = [
        RawSystemCandidate(
            name="NetSuite", source_file="doc1.txt",
            source_location="row 5", extraction_type="explicit",
            raw_evidence_quote="", verified=False,
            key_entities=["Invoices"], business_processes=["Finance"],
            criticality="high"
        ),
    ]
    score = _compute_confidence(candidates, {"doc1.txt"}, [])
    assert 0 < score < 95, f"Expected 1–94, got {score}"
    print(f"  PASS: partial confidence = {score}")


def test_alias_resolution():
    """SFDC and SF should resolve to Salesforce."""
    assert _resolve_canonical_name("sfdc", []) == "Salesforce"
    assert _resolve_canonical_name("aws", []) == "Amazon Web Services"
    assert _resolve_canonical_name("gcp", []) == "Google Cloud Platform"
    print("  PASS: alias resolution works")


def test_category_normalization():
    """Vague categories should be narrowed when the product name is clear."""
    hubspot = RawSystemCandidate(name="HubSpot", source_file="doc1.txt", category="Other")
    zendesk = RawSystemCandidate(name="Zendesk", source_file="doc1.txt", category="Other")
    assert _normalize_category("HubSpot", [hubspot], "Other").value == "Marketing Automation"
    assert _normalize_category("Zendesk", [zendesk], "Other").value == "Customer Support"
    print("  PASS: category normalization works")


def test_quote_exists_exact_match():
    text = "The sales team uses Salesforce CRM daily for pipeline management."
    assert _quote_exists_in_text("sales team uses Salesforce CRM", text)
    print("  PASS: exact quote match")


def test_quote_exists_fuzzy_match():
    text = "Our primary system is Salesforce, used across all sales operations."
    assert _quote_exists_in_text("primary system is Salesforce", text)
    print("  PASS: fuzzy quote match")


def test_hallucination_detection():
    """A quote that doesn't exist in text should fail the check."""
    text = "We use Jira for project management."
    fake_quote = "Salesforce is the backbone of our sales process"
    assert not _quote_exists_in_text(fake_quote, text)
    print("  PASS: hallucination detected (quote not in text)")


if __name__ == "__main__":
    tests = [
        test_confidence_high_explicit_verified,
        test_confidence_low_inferred_unverified,
        test_confidence_medium_explicit_not_verified,
        test_alias_resolution,
        test_category_normalization,
        test_quote_exists_exact_match,
        test_quote_exists_fuzzy_match,
        test_hallucination_detection,
    ]

    print(f"\nRunning {len(tests)} tests...\n")
    passed = 0
    for t in tests:
        try:
            print(f"[{t.__name__}]")
            t()
            passed += 1
        except AssertionError as e:
            print(f"  FAIL: {e}")
        except Exception as e:
            print(f"  ERROR: {e}")

    print(f"\n{passed}/{len(tests)} tests passed.")
