"""Tests for real PDF text extraction."""

import os
import sys
from pathlib import Path
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from loaders.loader import load_document


def test_pdf_text_extraction_roundtrip():
    """Create a real PDF with extractable text and ensure the loader reads it."""
    import fitz

    with tempfile.TemporaryDirectory() as temp_dir:
        pdf_path = Path(temp_dir) / "sample.pdf"
        doc = fitz.open()
        page = doc.new_page()
        page.insert_text((72, 72), "Salesforce and HubSpot are used for sales and marketing.")
        doc.save(str(pdf_path))
        doc.close()

        loaded = load_document(str(pdf_path))

        assert loaded.load_error is None
        assert loaded.pages
        assert "Salesforce" in loaded.pages[0]["text"]
        assert "HubSpot" in loaded.pages[0]["text"]


if __name__ == "__main__":
    test_pdf_text_extraction_roundtrip()
    print("PDF loader test passed")