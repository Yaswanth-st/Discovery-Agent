"""Tests for Level 3 connector generation."""

import os
import sys
import tempfile
import zipfile

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from connector_generator import generate_connector_package
from models import IntegrationGap


def test_connector_package_contains_runnable_artifacts():
    gap = IntegrationGap(
        gap_id="workday-okta-1234",
        source_system="Workday",
        destination_system="Okta",
        use_case_title="New hire onboarding",
        entity_type="Employee",
        trigger_event="New hire created",
        current_state="No verified integration found in source materials.",
        missing_capability="Automated transfer of employee data from Workday to Okta",
        priority_score=92,
        estimated_effort="Medium",
        confidence_score=88,
        business_value="high",
        recommendation="Build an authenticated Workday → Okta connector for employee events.",
        related_use_cases=["New hire onboarding"],
    )

    with tempfile.TemporaryDirectory() as temp_dir:
        artifact = generate_connector_package(gap, temp_dir)
        assert artifact.zip_path.endswith(".zip")

        with zipfile.ZipFile(artifact.zip_path) as archive:
            names = set(archive.namelist())
            assert "connector.py" in names
            assert "agent.yaml" in names
            assert "README.md" in names
            assert "tests/test_connector.py" in names

            connector_text = archive.read("connector.py").decode("utf-8")
            assert "max_retries" in connector_text
            assert "list_resources" in connector_text
            assert "create_resource" in connector_text


if __name__ == "__main__":
    test_connector_package_contains_runnable_artifacts()
    print("Level 3 connector generator test passed")