"""Diagnostic script — Groq version."""

import os, sys, json, re
sys.path.insert(0, os.path.dirname(__file__))
from dotenv import load_dotenv
load_dotenv()

print("=" * 60)
print("DISCOVERY AGENT — DIAGNOSTIC")
print("=" * 60)

print("\n[1] Checking Groq API key...")
api_key = os.getenv("GROQ_API_KEY")
if not api_key:
    print("  ERROR: GROQ_API_KEY not set in .env file")
    print("  Get a free key at: console.groq.com → API Keys → Create API Key")
    sys.exit(1)
print(f"  OK — key found: {api_key[:8]}...{api_key[-4:]}")

print("\n[2] Testing document loaders...")
from loaders.loader import load_document
for path in ["sample_docs/it_system_inventory.csv","sample_docs/onboarding_wiki.md","sample_docs/integration_audit.txt"]:
    if not os.path.exists(path):
        print(f"  MISSING: {path}"); continue
    doc = load_document(path)
    if doc.load_error:
        print(f"  ERROR: {doc.load_error}")
    else:
        chars = sum(len(p["text"]) for p in doc.pages)
        print(f"  OK — {doc.filename}: {len(doc.pages)} page(s), {chars} chars")

print("\n[3] Testing Groq API connection...")
from groq import Groq
client = Groq(api_key=api_key)
try:
    r = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": "Reply with just the word: CONNECTED"}],
        max_tokens=10,
    )
    reply = r.choices[0].message.content.strip()
    print(f"  OK — Groq responded: '{reply}'")
except Exception as e:
    print(f"  ERROR: {type(e).__name__}: {e}")
    sys.exit(1)

print("\n[4] Testing real extraction on integration_audit.txt...")
doc = load_document("sample_docs/integration_audit.txt")
text = doc.pages[0]["text"][:800]
prompt = f"""List software systems explicitly named in this text.
Respond ONLY with a JSON array, no markdown, no explanation.
Each item: {{"name":"...","category":"CRM/ERP/Other"}}

TEXT:
{text}"""
try:
    r = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": prompt}],
        temperature=0,
        max_tokens=1000,
    )
    raw = re.sub(r"```json|```", "", r.choices[0].message.content).strip()
    data = json.loads(raw)
    print(f"  Found {len(data)} system(s):")
    for item in data:
        print(f"    - {item.get('name')} ({item.get('category')})")
except Exception as e:
    print(f"  ERROR: {type(e).__name__}: {e}")
    sys.exit(1)

print(f"\n{'='*60}")
print("All checks passed!")
print("Run: python main.py --docs ./sample_docs --output ./output")
print(f"{'='*60}")
