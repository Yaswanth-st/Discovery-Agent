"""Shared Level 1 discovery pipeline used by the CLI and the UI."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from groq import Groq

from extractor.extractor import extract_from_document, _fallback_extract
from loaders.loader import load_document
from output.writer import write_json, write_report
from validator.validator import validate_and_score


@dataclass
class Level1Artifacts:
    json_path: str
    report_path: str
    result: object
    processed_documents: int
    candidates: int


def run_level1_pipeline(
    client: Groq,
    doc_files: Iterable[Path],
    output_path: str | Path,
    on_event: Callable[[str, dict], None] | None = None,
) -> Level1Artifacts:
    """Run the full Level 1 pipeline and persist artifacts."""
    all_candidates, errors, processed = _collect_candidates(doc_files, on_event, lambda doc: extract_from_document(client, doc.pages, doc.filename))

    return _finalize_level1(all_candidates, errors, processed, output_path, on_event)


def run_level1_fallback_pipeline(
    doc_files: Iterable[Path],
    output_path: str | Path,
    on_event: Callable[[str, dict], None] | None = None,
) -> Level1Artifacts:
    """Run Level 1 without Groq by using the deterministic fallback extractor."""

    def _extract_fallback(doc):
        candidates = []
        for page in doc.pages:
            candidates.extend(_fallback_extract(page["text"], page["source"], doc.filename))
        return candidates

    all_candidates, errors, processed = _collect_candidates(doc_files, on_event, _extract_fallback)
    return _finalize_level1(all_candidates, errors, processed, output_path, on_event)


def _collect_candidates(
    doc_files: Iterable[Path],
    on_event: Callable[[str, dict], None] | None,
    extractor: Callable[[object], list],
) -> tuple[list, list[str], int]:
    all_candidates = []
    errors: list[str] = []
    processed = 0

    for doc_file in doc_files:
        _emit(on_event, "document_load_started", document=doc_file.name)
        loaded = load_document(str(doc_file))

        if loaded.load_error:
            errors.append(f"{doc_file.name}: {loaded.load_error}")
            _emit(on_event, "document_load_failed", document=doc_file.name, error=loaded.load_error)
            continue

        if not loaded.pages:
            errors.append(f"{doc_file.name}: no readable content")
            _emit(on_event, "document_empty", document=doc_file.name)
            continue

        candidates = extractor(loaded)
        all_candidates.extend(candidates)
        processed += 1
        _emit(on_event, "document_extracted", document=doc_file.name, candidates=len(candidates))

    return all_candidates, errors, processed


def _finalize_level1(
    all_candidates: list,
    errors: list[str],
    processed: int,
    output_path: str | Path,
    on_event: Callable[[str, dict], None] | None,
) -> Level1Artifacts:
    result = validate_and_score(all_candidates, processed, errors)
    _emit(
        on_event,
        "validation_complete",
        processed_documents=result.total_documents_processed,
        discovered=result.total_systems_discovered,
        review_count=result.systems_needing_review,
    )

    json_path = write_json(result, str(output_path))
    report_path = write_report(result, str(output_path))
    _emit(on_event, "artifacts_written", json=json_path, report=report_path)

    return Level1Artifacts(
        json_path=json_path,
        report_path=report_path,
        result=result,
        processed_documents=processed,
        candidates=len(all_candidates),
    )


def _emit(handler: Callable[[str, dict], None] | None, event: str, **payload):
    if handler:
        handler(event, payload)
