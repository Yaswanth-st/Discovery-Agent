"""Structured audit logging for Discovery Agent runs.

The log is a JSONL trail that can be consumed by humans or tooling.
"""

from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_lock = threading.Lock()
_audit_log_path: Path | None = None


def configure_audit_log(path: str | Path | None) -> None:
    """Set the destination for JSONL audit events."""
    global _audit_log_path
    _audit_log_path = Path(path) if path else None
    if _audit_log_path:
        _audit_log_path.parent.mkdir(parents=True, exist_ok=True)
        _audit_log_path.touch(exist_ok=True)


def get_audit_log_path() -> Path | None:
    """Return the active audit log path, if configured."""
    return _audit_log_path


def log_event(event_type: str, **payload: Any) -> None:
    """Append a structured event to the audit log when configured."""
    if not _audit_log_path:
        return

    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": event_type,
        **payload,
    }

    line = json.dumps(event, ensure_ascii=True, default=str)
    with _lock:
        with _audit_log_path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")