"""Streamlit UI for the Discovery Agent.

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import io
import json
import os
import tempfile
from pathlib import Path

import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from groq import Groq

from connector_generator import generate_connector_package
from gap_analysis import analyze_gaps
from level1_service import run_level1_pipeline, run_level1_fallback_pipeline
from models import ExtractionResult, GapAnalysisResult
from storage import ProjectStore
from audit import configure_audit_log

load_dotenv()

APP_ROOT = Path(__file__).resolve().parent
DEFAULT_OUTPUT = APP_ROOT / "output" / "ui"
DEFAULT_DB = DEFAULT_OUTPUT / "discovery_agent.sqlite3"
SAMPLE_DOCS = APP_ROOT / "sample_docs"

st.set_page_config(page_title="Discovery Agent — Systems & Integrations", page_icon="AI", layout="wide")

st.markdown(
    """
    <style>
      .block-container { padding-top: 1.25rem; }
      .hero {
        padding: 1.25rem 1.5rem;
        border-radius: 20px;
        background: linear-gradient(135deg, #111827 0%, #312e81 50%, #7c3aed 100%);
        color: white;
        box-shadow: 0 18px 50px rgba(17,24,39,0.25);
      }
      .hero h1 { margin: 0; font-size: 2rem; }
      .hero p { margin: 0.35rem 0 0; opacity: 0.85; }
      .metric-card {
        padding: 0.9rem 1rem;
        border: 1px solid rgba(148,163,184,0.35);
        border-radius: 16px;
        background: rgba(255,255,255,0.8);
      }
      .section-label { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.12em; color: #6b7280; }
    </style>
    """,
    unsafe_allow_html=True,
)


def _ensure_environment() -> ProjectStore:
    DEFAULT_OUTPUT.mkdir(parents=True, exist_ok=True)
    store = ProjectStore(DEFAULT_DB)
    configure_audit_log(DEFAULT_OUTPUT / "audit_log.jsonl")
    return store


def _sample_level2_goals() -> str:
    return (
        "- New hire onboarding should provision Okta, Slack, Google Workspace, GitHub, and AWS access automatically.\n"
        "- Finance wants Expensify expenses to sync into NetSuite every night with receipts and coding information.\n"
        "- Marketing leads from HubSpot should flow into Salesforce with deduplication and retry handling.\n"
        "- Engineering wants GitHub pull requests linked to Jira tickets with status updates in Slack.\n"
        "- Revenue recognition should move from Stripe into NetSuite and Snowflake for reporting.\n"
    )


def _load_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""


def _extract_uploaded_files(uploaded_files, temp_dir: Path) -> list[Path]:
    paths: list[Path] = []
    if not uploaded_files:
        return paths
    temp_dir.mkdir(parents=True, exist_ok=True)
    for uploaded in uploaded_files:
        target = temp_dir / uploaded.name
        target.write_bytes(uploaded.getbuffer())
        paths.append(target)
    return paths


def _get_client(api_key: str | None) -> Groq:
    key = api_key or os.getenv("GROQ_API_KEY")
    if not key:
        raise RuntimeError("GROQ_API_KEY is required for Level 1 runs.")
    return Groq(api_key=key)


def _load_extraction_result_from_payload(payload_json: str) -> ExtractionResult:
    return ExtractionResult.model_validate(json.loads(payload_json))


def _load_gap_result_from_payload(payload_json: str) -> GapAnalysisResult:
    return GapAnalysisResult.model_validate(json.loads(payload_json))


def _run_level1(uploaded_files, api_key: str, output_dir: Path, store: ProjectStore, use_fallback: bool = False):
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_root = Path(temp_dir)
        doc_paths = _extract_uploaded_files(uploaded_files, temp_root)
        if not doc_paths:
            doc_paths = list(SAMPLE_DOCS.iterdir())

        if use_fallback:
            artifacts = run_level1_fallback_pipeline(doc_paths, output_dir)
        else:
            client = _get_client(api_key)
            artifacts = run_level1_pipeline(client, doc_paths, output_dir)
        run_id = store.save_run(
            "level1",
            "System Discovery Run",
            [str(path) for path in doc_paths],
            artifacts.result,
            summary=artifacts.result.agent_notes,
        )
        store.save_artifact(run_id, "json", artifacts.json_path, {"kind": "level1-json"})
        store.save_artifact(run_id, "markdown", artifacts.report_path, {"kind": "level1-report"})
        return run_id, artifacts


def _render_level1(store: ProjectStore):
    st.subheader("Level 1 — System Discovery")
    st.caption("Upload supporting documents or run the included sample set to produce a validated system inventory.")

    uploaded_files = st.file_uploader(
        "Upload supporting documents",
        type=["pdf", "png", "jpg", "jpeg", "webp", "txt", "md", "html", "htm", "csv", "xls", "xlsx"],
        accept_multiple_files=True,
    )
    api_key = st.text_input("API key (GROQ)", type="password", value=os.getenv("GROQ_API_KEY", ""))
    output_dir = Path(st.text_input("Output directory", value=str(DEFAULT_OUTPUT)))

    col1, col2 = st.columns(2)
    with col1:
        run_button = st.button("Run Discovery", type="primary", use_container_width=True)
    with col2:
        demo_button = st.button("Run Sample (Demo)", use_container_width=True)

    if run_button or demo_button:
        try:
            with st.spinner("Running system discovery — this may take a few moments..."):
                selected_files = uploaded_files if run_button else []
                run_id, artifacts = _run_level1(selected_files, api_key, output_dir, store, use_fallback=demo_button)
                st.session_state["level1_run_id"] = run_id
                st.session_state["level1_result"] = artifacts.result.model_dump()
                st.session_state["level1_json_path"] = artifacts.json_path
                st.session_state["level1_report_path"] = artifacts.report_path
                st.success(f"System discovery completed successfully — stored as run #{run_id}.")
        except Exception as exc:
            st.error(str(exc))

    latest = None
    if st.session_state.get("level1_result"):
        latest = ExtractionResult.model_validate(st.session_state["level1_result"])
    else:
        latest_run = store.latest_run("level1")
        if latest_run:
            latest = _load_extraction_result_from_payload(latest_run["payload_json"])

    if latest:
        _render_level1_result(latest)
        if st.session_state.get("level1_json_path"):
            st.download_button(
                "Export JSON",
                Path(st.session_state["level1_json_path"]).read_bytes(),
                file_name="discovery_result.json",
                mime="application/json",
            )
        if st.session_state.get("level1_report_path"):
            st.download_button(
                "Export report (Markdown)",
                Path(st.session_state["level1_report_path"]).read_bytes(),
                file_name="discovery_report.md",
                mime="text/markdown",
            )


def _render_level1_result(result: ExtractionResult):
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Documents", result.total_documents_processed)
    m2.metric("Systems", result.total_systems_discovered)
    m3.metric("Needs review", result.systems_needing_review)
    m4.metric("High confidence", sum(1 for item in result.systems if item.confidence_tier.value == "high"))

    st.markdown("### Discovered Inventory")
    rows = []
    for system in result.systems:
        rows.append(
            {
                "System": system.name,
                "Category": system.category.value,
                "Confidence": system.confidence_score,
                "Tier": system.confidence_tier.value,
                "Review": system.human_review_required,
                "Criticality": system.criticality.value,
            }
        )
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    chosen = st.selectbox("Select system to inspect evidence", [system.name for system in result.systems], key="level1_system_select")
    if chosen:
        selected = next((system for system in result.systems if system.name == chosen), None)
        if selected:
            st.markdown(f"**{selected.name}**")
            st.write(selected.inference_notes or selected.review_reason or result.agent_notes)
            evidence_rows = [
                {
                    "Source": item.source_file,
                    "Location": item.location,
                    "Text": item.raw_text,
                    "Method": item.extraction_method,
                }
                for item in selected.evidence_chain
            ]
            st.dataframe(pd.DataFrame(evidence_rows), use_container_width=True, hide_index=True)
    else:
        st.info("No systems were extracted from this run. Try running the discovery with additional documents or use the sample dataset for a demo.")


def _render_level2(store: ProjectStore):
    st.subheader("Level 2 — Use-Case Mapping & Gap Analysis")
    st.caption("Map automation objectives to discovered systems and identify missing or incomplete integrations.")

    latest_level1 = st.session_state.get("level1_result")
    if not latest_level1:
        latest_run = store.latest_run("level1")
        if latest_run:
            latest_level1 = json.loads(latest_run["payload_json"])

    if not latest_level1:
        st.info("Please run Level 1 discovery first or load a saved run from History.")
        return

    inventory = ExtractionResult.model_validate(latest_level1)
    goals_text = st.text_area("Automation goals / objectives", value=st.session_state.get("level2_goals", _sample_level2_goals()), height=220)
    existing_text = st.text_area(
        "Existing integrations / evidence (optional)",
        value=st.session_state.get("level2_existing", _load_text_file(SAMPLE_DOCS / "integration_audit.txt")),
        height=180,
    )

    st.session_state["level2_goals"] = goals_text
    st.session_state["level2_existing"] = existing_text

    if st.button("Analyze gaps & recommend", type="primary", use_container_width=True):
        gap_result = analyze_gaps(inventory.systems, goals_text, existing_text)
        run_id = store.save_run(
            "level2",
            "Integration Gap Analysis",
            ["level1_inventory", "automation_goals"],
            gap_result,
            summary=gap_result.summary,
        )
        st.session_state["level2_run_id"] = run_id
        st.session_state["level2_result"] = gap_result.model_dump()
        st.success(f"Level 2 analysis completed — stored as run #{run_id}.")

    current = st.session_state.get("level2_result")
    if current:
        gap_result = GapAnalysisResult.model_validate(current)
        _render_level2_result(gap_result)


def _render_level2_result(result: GapAnalysisResult):
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Use cases", result.total_use_cases)
    c2.metric("Mapped", result.mapped_use_cases)
    c3.metric("Gaps", result.total_gaps)
    c4.metric("Systems in scope", result.systems_in_scope)

    st.write(result.summary)

    use_case_rows = [item.model_dump() for item in result.use_cases]
    st.markdown("### Use case mapping")
    st.dataframe(pd.DataFrame(use_case_rows), use_container_width=True, hide_index=True)

    gap_rows = [item.model_dump() for item in result.gaps]
    st.markdown("### Ranked gaps")
    st.dataframe(pd.DataFrame(gap_rows), use_container_width=True, hide_index=True)


def _render_level3(store: ProjectStore):
    st.subheader("Level 3 — Connector Generation")
    st.caption("Generate production-ready connector packages and an agent definition for an identified integration gap.")

    current = st.session_state.get("level2_result")
    if not current:
        latest_run = store.latest_run("level2")
        if latest_run:
            current = json.loads(latest_run["payload_json"])

    if not current:
        st.info("Please run Level 2 analysis first to identify a gap for connector generation.")
        return

    result = GapAnalysisResult.model_validate(current)
    if not result.gaps:
        st.info("No missing integrations were identified from the provided inputs.")
        return

    selected_gap = st.selectbox(
        "Choose a gap",
        options=[gap.gap_id for gap in result.gaps],
        format_func=lambda gap_id: next(
            f"{gap.source_system} → {gap.destination_system} | {gap.use_case_title}"
            for gap in result.gaps if gap.gap_id == gap_id
        ),
        key="level3_gap_select",
    )
    gap = next(item for item in result.gaps if item.gap_id == selected_gap)

    st.markdown("### Gap details & recommendations")
    st.write(gap.recommendation)
    st.write(gap.missing_capability)
    st.write(f"Priority score: {gap.priority_score} / 100")

    if st.button("Generate Connector Package", type="primary", use_container_width=True):
        artifact = generate_connector_package(gap, DEFAULT_OUTPUT)
        run_id = store.save_run(
            "level3",
            "Connector Generation",
            [gap.gap_id],
            artifact,
            summary=artifact.setup_notes,
        )
        store.save_artifact(run_id, "zip", artifact.zip_path, artifact)
        st.session_state["level3_artifact"] = artifact.model_dump()
        st.success(f"Connector package generated and stored as run #{run_id}.")

    current_artifact = st.session_state.get("level3_artifact")
    if current_artifact:
        artifact_data = current_artifact
        st.markdown("### Generated artifact")
        st.write(artifact_data["artifact_name"])
        st.write(artifact_data["setup_notes"])
        st.write(f"Connector directory: {artifact_data['output_dir']}")

        zip_path = Path(artifact_data["zip_path"])
        if zip_path.exists():
            st.download_button(
                "Export connector (ZIP)",
                zip_path.read_bytes(),
                file_name=zip_path.name,
                mime="application/zip",
            )

        connector_file = Path(artifact_data["output_dir"]) / "connector.py"
        if connector_file.exists():
            st.code(connector_file.read_text(encoding="utf-8"), language="python")


def _render_history(store: ProjectStore):
    st.subheader("History")
    runs = store.list_runs()
    if not runs:
        st.info("No persisted runs found.")
        return

    st.dataframe(pd.DataFrame(runs), use_container_width=True, hide_index=True)

    selected = st.selectbox("Select run to inspect", [run["id"] for run in runs])
    run = store.get_run(selected)
    if not run:
        return

    st.markdown(f"### Run #{run['id']} - {run['title']}")
    st.write(run["summary"])
    st.code(run["payload_json"], language="json")


def main():
    store = _ensure_environment()

    st.markdown(
        """
        <div class="hero">
            <h1>Discovery Agent</h1>
            <p>Enterprise-ready discovery and integration planning — inventory, gap analysis, and connector generation.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.write("Use the tabs below to discover systems, map automation goals to your inventory, and generate connector artifacts.")

    level1_tab, level2_tab, level3_tab, history_tab = st.tabs([
        "Level 1",
        "Level 2",
        "Level 3",
        "History",
    ])

    with level1_tab:
        _render_level1(store)

    with level2_tab:
        _render_level2(store)

    with level3_tab:
        _render_level3(store)

    with history_tab:
        _render_history(store)


if __name__ == "__main__":
    main()
