"""
Core data models for the Discovery Agent.
All output is validated against these schemas before being written.
"""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class ConfidenceTier(str, Enum):
    HIGH = "high"          # 95%+ — explicitly named with context
    MEDIUM = "medium"      # 70–94% — inferred from strong signals
    LOW = "low"            # <70% — weak signal, needs human review


class SystemCategory(str, Enum):
    CRM = "CRM"
    ERP = "ERP"
    HRIS = "HRIS"
    DATA_WAREHOUSE = "Data Warehouse"
    COMMUNICATION = "Communication"
    PROJECT_MANAGEMENT = "Project Management"
    FINANCE = "Finance"
    DEVOPS = "DevOps"
    ECOMMERCE = "E-Commerce"
    ANALYTICS = "Analytics"
    STORAGE = "Storage"
    IDENTITY = "Identity & Auth"
    CUSTOMER_SUPPORT = "Customer Support"
    MARKETING_AUTOMATION = "Marketing Automation"
    CLOUD_PLATFORM = "Cloud Platform"
    COLLABORATION = "Collaboration"
    DATA_INTEGRATION = "Data Integration"
    OTHER = "Other"


class Criticality(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"


class EvidenceItem(BaseModel):
    """A single piece of evidence supporting a system's existence."""
    source_file: str = Field(description="Filename the evidence came from")
    location: str = Field(description="Page number, row, or section where found")
    raw_text: str = Field(description="Exact text snippet from the source")
    extraction_method: str = Field(description="How this was found: explicit/inferred/ocr")


class DiscoveredSystem(BaseModel):
    """A single system discovered from the document collection."""
    name: str = Field(description="Canonical system name")
    aliases: list[str] = Field(default_factory=list, description="Other names found (e.g. SFDC for Salesforce)")
    category: SystemCategory = Field(description="Type of system")
    auth_method: Optional[str] = Field(None, description="Authentication method if found")
    key_entities: list[str] = Field(default_factory=list, description="Data entities this system manages")
    business_processes: list[str] = Field(default_factory=list, description="Processes this system supports")
    criticality: Criticality = Field(default=Criticality.UNKNOWN)
    confidence_score: int = Field(ge=0, le=100, description="0–100 confidence score")
    confidence_tier: ConfidenceTier
    evidence_chain: list[EvidenceItem] = Field(description="All evidence backing this finding")
    inference_notes: Optional[str] = Field(None, description="Explanation of any inference made")
    human_review_required: bool = Field(description="True if confidence < 70%")
    review_reason: Optional[str] = Field(None, description="Why human review is needed")


class ExtractionResult(BaseModel):
    """Final output of the Discovery Agent for a document collection."""
    total_documents_processed: int
    total_systems_discovered: int
    systems_needing_review: int
    systems: list[DiscoveredSystem]
    processing_errors: list[str] = Field(default_factory=list)
    agent_notes: str = Field(description="Summary of what the agent found and any concerns")


class UseCaseType(str, Enum):
    ONBOARDING = "Onboarding"
    SALES = "Sales"
    FINANCE = "Finance"
    SUPPORT = "Support"
    ENGINEERING = "Engineering"
    MARKETING = "Marketing"
    DATA = "Data"
    OTHER = "Other"


class UseCaseMapping(BaseModel):
    """A business automation use case mapped to the systems it touches."""

    title: str
    description: str
    use_case_type: UseCaseType = UseCaseType.OTHER
    involved_systems: list[str] = Field(default_factory=list)
    source_system: Optional[str] = None
    destination_system: Optional[str] = None
    entity_type: Optional[str] = None
    trigger_event: Optional[str] = None
    existing_integration: bool = False
    confidence_score: int = Field(ge=0, le=100)
    frequency_per_month: Optional[int] = None
    business_impact: str = Field(default="medium")
    notes: Optional[str] = None


class IntegrationGap(BaseModel):
    """A missing integration identified from a business use case."""

    gap_id: str
    source_system: str
    destination_system: str
    use_case_title: str
    entity_type: str
    trigger_event: str
    current_state: str
    missing_capability: str
    priority_score: int = Field(ge=0, le=100)
    estimated_effort: str
    confidence_score: int = Field(ge=0, le=100)
    business_value: str
    recommendation: str
    related_use_cases: list[str] = Field(default_factory=list)


class GapAnalysisResult(BaseModel):
    """Structured output for Level 2."""

    total_use_cases: int
    mapped_use_cases: int
    total_gaps: int
    systems_in_scope: int
    use_cases: list[UseCaseMapping]
    gaps: list[IntegrationGap]
    summary: str


class ConnectorArtifact(BaseModel):
    """Metadata describing generated Level 3 code artifacts."""

    gap_id: str
    artifact_name: str
    output_dir: str
    files: list[str]
    zip_path: str
    setup_notes: str
