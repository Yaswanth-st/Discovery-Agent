"""
Document loaders — each format gets a specialist loader.
Returns (raw_text, metadata) so the extractor works on clean text
regardless of the source format.
"""

import io
import os
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

from audit import log_event


@dataclass
class LoadedDocument:
    filename: str
    file_type: str
    pages: list[dict]   # each page: {"page": int, "text": str, "source": str}
    load_error: Optional[str] = None


def load_document(filepath: str) -> LoadedDocument:
    """Route a file to the correct loader based on its extension."""
    path = Path(filepath)
    ext = path.suffix.lower()
    log_event("loader_routed", file=path.name, extension=ext)

    loaders = {
        ".pdf": _load_pdf,
        ".png": _load_image,
        ".jpg": _load_image,
        ".jpeg": _load_image,
        ".webp": _load_image,
        ".txt": _load_text,
        ".md": _load_text,
        ".html": _load_html,
        ".htm": _load_html,
        ".xlsx": _load_spreadsheet,
        ".xls": _load_spreadsheet,
        ".csv": _load_csv,
    }

    loader = loaders.get(ext)
    if not loader:
        log_event("loader_unsupported", file=path.name, extension=ext)
        return LoadedDocument(
            filename=path.name,
            file_type=ext,
            pages=[],
            load_error=f"Unsupported file type: {ext}"
        )

    try:
        log_event("loader_start", file=path.name, extension=ext)
        return loader(filepath)
    except Exception as e:
        log_event("loader_error", file=path.name, extension=ext, error=str(e))
        return LoadedDocument(
            filename=path.name,
            file_type=ext,
            pages=[],
            load_error=f"Failed to load: {str(e)}"
        )


def _load_pdf(filepath: str) -> LoadedDocument:
    import fitz  # PyMuPDF
    path = Path(filepath)
    doc = fitz.open(filepath)
    pages = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text().strip()

        # If page has no text (scanned PDF), fall back to OCR
        if not text:
            log_event("pdf_text_missing", file=path.name, page=page_num + 1, fallback="ocr")
            text = _ocr_pdf_page(page)

        if text:
            pages.append({
                "page": page_num + 1,
                "text": text,
                "source": f"{path.name} p.{page_num + 1}"
            })

    doc.close()
    return LoadedDocument(filename=path.name, file_type="pdf", pages=pages)


def _ocr_pdf_page(page) -> str:
    """OCR a single PDF page that has no extractable text."""
    try:
        import pytesseract
        from PIL import Image
        pix = page.get_pixmap(dpi=200)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        text = pytesseract.image_to_string(img).strip()
        log_event("pdf_ocr_complete", text_found=bool(text))
        return text
    except Exception:
        log_event("pdf_ocr_failed")
        return ""


def _load_image(filepath: str) -> LoadedDocument:
    try:
        import pytesseract
        from PIL import Image
        path = Path(filepath)
        img = Image.open(filepath)
        text = pytesseract.image_to_string(img).strip()
        pages = [{"page": 1, "text": text, "source": path.name}] if text else []
        log_event("image_loaded", file=path.name, text_found=bool(text))
        return LoadedDocument(filename=path.name, file_type="image", pages=pages)
    except ImportError:
        # pytesseract not available — return empty with note
        path = Path(filepath)
        log_event("image_ocr_unavailable", file=path.name)
        return LoadedDocument(
            filename=path.name,
            file_type="image",
            pages=[],
            load_error="pytesseract not installed — image OCR skipped"
        )


def _load_text(filepath: str) -> LoadedDocument:
    path = Path(filepath)
    text = path.read_text(encoding="utf-8", errors="replace").strip()
    pages = [{"page": 1, "text": text, "source": path.name}] if text else []
    log_event("text_loaded", file=path.name, text_found=bool(text))
    return LoadedDocument(filename=path.name, file_type="text", pages=pages)


def _load_html(filepath: str) -> LoadedDocument:
    from bs4 import BeautifulSoup
    path = Path(filepath)
    html = path.read_text(encoding="utf-8", errors="replace")
    soup = BeautifulSoup(html, "html.parser")

    # Remove script/style noise
    for tag in soup(["script", "style", "nav", "footer"]):
        tag.decompose()

    text = soup.get_text(separator="\n").strip()
    pages = [{"page": 1, "text": text, "source": path.name}] if text else []
    log_event("html_loaded", file=path.name, text_found=bool(text))
    return LoadedDocument(filename=path.name, file_type="html", pages=pages)


def _load_spreadsheet(filepath: str) -> LoadedDocument:
    import openpyxl
    path = Path(filepath)
    wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
    pages = []

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        rows = []
        for row in ws.iter_rows(values_only=True):
            cells = [str(c) if c is not None else "" for c in row]
            if any(c.strip() for c in cells):
                rows.append(" | ".join(cells))
        if rows:
            pages.append({
                "page": sheet_name,
                "text": "\n".join(rows),
                "source": f"{path.name} [{sheet_name}]"
            })

    wb.close()
    log_event("spreadsheet_loaded", file=path.name, sheets=len(pages))
    return LoadedDocument(filename=path.name, file_type="spreadsheet", pages=pages)


def _load_csv(filepath: str) -> LoadedDocument:
    import csv
    path = Path(filepath)
    rows = []
    with open(filepath, encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        for i, row in enumerate(reader):
            rows.append(f"Row {i+1}: " + " | ".join(row))

    text = "\n".join(rows)
    pages = [{"page": 1, "text": text, "source": path.name}] if text else []
    log_event("csv_loaded", file=path.name, text_found=bool(text))
    return LoadedDocument(filename=path.name, file_type="csv", pages=pages)
