# Automation Goals

- New hire onboarding should provision Okta, Slack, Google Workspace, GitHub, and AWS access automatically.
- Finance wants Expensify expenses to sync into NetSuite every night with receipts and coding information.
- Marketing leads from HubSpot should flow into Salesforce with deduplication and retry handling.
- Engineering wants GitHub pull requests linked to Jira tickets with status updates in Slack.
- Revenue recognition should move from Stripe into NetSuite and Snowflake for reporting.

## Existing Integrations

- Salesforce → NetSuite (order sync)
- HubSpot → Salesforce (lead sync)
- Snowflake ← multiple sources (Salesforce, NetSuite, Zendesk, Stripe)
- Zendesk → Slack (critical ticket notifications)
