# New Employee Onboarding Guide

Welcome to the team. This guide walks you through the systems you'll need access to in your first week.

## Day 1: Access Requests

Submit an IT ticket via our helpdesk (ServiceNow) to request access to all systems below. 
Your manager will approve the ticket.

### Required for Everyone
- **Okta** — Single sign-on portal. All other apps are accessed through Okta. 
  You will receive an Okta invite on your first morning.
- **Slack** — Team communication. Join #general and your department channel.
- **Google Workspace** — Email (Gmail), calendar (Google Calendar), and Docs.
- **1Password** — Password manager. IT will set this up for you.

### Engineering Team Only
- **GitHub** — You'll be added to the engineering org. Use SSO via Okta.
- **AWS** — Access via IAM role assigned to your team. Never use root credentials.
- **Datadog** — Application monitoring and logging. Alerts go to Slack #alerts channel.
- **PagerDuty** — On-call rotation management. Engineering leads set this up.

### Sales Team Only  
- **Salesforce** — Our CRM. All customer data, pipeline, and activity logs live here.
  We use the SFDC Enterprise edition. Contact the RevOps team for custom reports.
- **Outreach** — Sales engagement platform for sequences and email tracking.
- **LinkedIn Sales Navigator** — Prospecting tool, integrated with SFDC.

### Finance Team Only
- **NetSuite** — ERP for all financial operations. Token-based authentication.
- **Coupa** — Procurement and purchase orders. Integrated with NetSuite.
- **Expensify** — Expense reporting. Sync happens nightly to NetSuite.

## Helpful Tips
- The SFDC → NetSuite sync runs every 4 hours. If an order doesn't appear in NetSuite, wait and check again.
- Datadog dashboards for production are shared in the #engineering-metrics Slack channel.
- For any system not listed here, check the internal wiki or ask in #it-help.
