"""
Multi-pass extractor — uses Groq API (free, no credit card needed).

3 focused LLM calls per document:
  Pass 1: Explicitly named systems
  Pass 2: Implied/inferred systems
  Pass 3: Evidence verification (hallucination guard)
"""

import json
import re
import time
from dataclasses import dataclass, field
from typing import Optional

from groq import Groq

from audit import log_event

MODEL = "llama-3.3-70b-versatile"   # Free on Groq, very capable


@dataclass
class RawSystemCandidate:
    name: str
    aliases: list[str] = field(default_factory=list)
    category: str = "Other"
    auth_method: Optional[str] = None
    key_entities: list[str] = field(default_factory=list)
    business_processes: list[str] = field(default_factory=list)
    criticality: str = "unknown"
    source_file: str = ""
    source_location: str = ""
    raw_evidence_quote: str = ""
    extraction_type: str = "explicit"
    verified: bool = False


SYSTEM_CATEGORIES = [
    "CRM", "ERP", "HRIS", "Data Warehouse", "Communication",
    "Project Management", "Finance", "DevOps", "E-Commerce",
    "Analytics", "Storage", "Identity & Auth", "Customer Support",
    "Marketing Automation", "Cloud Platform", "Collaboration", "Data Integration",
    "Other"
]

FALLBACK_SYSTEM_PATTERNS: list[tuple[str, str, str]] = [
    (r"\bServiceNow\b", "ServiceNow", "Project Management"),
    (r"\bOkta\b", "Okta", "Identity & Auth"),
    (r"\bSlack\b", "Slack", "Communication"),
    (r"\bGoogle Workspace\b", "Google Workspace", "Communication"),
    (r"\b1Password\b", "1Password", "Identity & Auth"),
    (r"\bGitHub\b", "GitHub", "DevOps"),
    (r"\bAWS\b|Amazon Web Services", "AWS", "Cloud Platform"),
    (r"\bDatadog\b", "Datadog", "DevOps"),
    (r"\bPagerDuty\b", "PagerDuty", "DevOps"),
    (r"\bSalesforce\b|\bSFDC\b", "Salesforce", "CRM"),
    (r"\bOutreach\b", "Outreach", "Marketing Automation"),
    (r"LinkedIn Sales Navigator", "LinkedIn Sales Navigator", "CRM"),
    (r"\bNetSuite\b", "NetSuite", "ERP"),
    (r"\bCoupa\b", "Coupa", "Finance"),
    (r"\bExpensify\b", "Expensify", "Finance"),
    (r"\bWorkday\b", "Workday", "HRIS"),
    (r"\bHubSpot\b", "HubSpot", "Marketing Automation"),
    (r"\bZendesk\b", "Zendesk", "Customer Support"),
    (r"\bStripe\b", "Stripe", "Finance"),
    (r"\bSnowflake\b", "Snowflake", "Data Warehouse"),
    (r"\bJira\b", "Jira", "Project Management"),
]


def extract_from_document(client: Groq, pages: list[dict], filename: str) -> list[RawSystemCandidate]:
    candidates: list[RawSystemCandidate] = []

    for page in pages:
        text = page["text"]
        source = page["source"]

        if len(text.strip()) < 30:
            continue

        text_chunk = text[:4000] if len(text) > 4000 else text

        log_event("extraction_pass_started", file=filename, source=source, pass_name="explicit")
        explicit = _pass1_explicit(client, text_chunk, source, filename)
        candidates.extend(explicit)
        log_event("extraction_pass_finished", file=filename, source=source, pass_name="explicit", candidates=len(explicit))

        if len(text_chunk) > 200:
            log_event("extraction_pass_started", file=filename, source=source, pass_name="inferred")
            implied = _pass2_implied(client, text_chunk, source, filename)
            candidates.extend(implied)
            log_event("extraction_pass_finished", file=filename, source=source, pass_name="inferred", candidates=len(implied))

        all_names = [c.name for c in candidates if c.source_file == filename]
        if all_names:
            log_event("verification_started", file=filename, systems=len(all_names))
            _pass3_verify(client, text_chunk, source, candidates)
            log_event("verification_finished", file=filename)
        else:
            fallback = _fallback_extract(text_chunk, source, filename)
            if fallback:
                candidates.extend(fallback)
                log_event("fallback_extraction", file=filename, candidates=len(fallback))

    return candidates


def _pass1_explicit(client, text, source, filename):
    prompt = f"""You are analyzing a business document to find software systems explicitly named in it.

DOCUMENT TEXT:
{text}

TASK: List ONLY software systems, platforms, or tools that are EXPLICITLY named by name in the text above.
Do NOT infer or guess. If a system is not clearly named, do not include it.

For each system found, respond with a JSON array. Each item must have:
- "name": canonical product name (e.g. "Salesforce" not "SF" or "the CRM")
- "aliases": other names used in the text for this system (e.g. ["SFDC", "SF"])
- "category": one of {SYSTEM_CATEGORIES}
- "auth_method": authentication method if mentioned, else null
- "key_entities": data objects this system manages, mentioned in text
- "business_processes": business processes it supports, mentioned in text
- "criticality": "high", "medium", "low", or "unknown"

Respond with ONLY a valid JSON array. No explanation. No markdown fences. If no systems found, return []."""
    return _call_llm(client, prompt, source, filename, "explicit")


def _pass2_implied(client, text, source, filename):
    prompt = f"""You are analyzing a business document to find software systems IMPLIED but not directly named.

DOCUMENT TEXT:
{text}

TASK: Find software systems STRONGLY implied by the text. Examples:
- "our CRM" without naming it
- Abbreviations mapping to known products (e.g. "Apex triggers" implies Salesforce)
- Internal nicknames for known platforms

Do NOT include already explicitly named systems. Do NOT guess without evidence.

Respond with a JSON array. Each item:
- "name": inferred canonical product name
- "aliases": terms in the text that led to this inference
- "category": one of {SYSTEM_CATEGORIES}
- "auth_method": null
- "key_entities": only if clearly mentioned
- "business_processes": only if clearly mentioned
- "criticality": "unknown" unless clearly stated

Respond with ONLY a valid JSON array. No explanation. No markdown fences. If nothing implied, return []."""
    return _call_llm(client, prompt, source, filename, "inferred")


def _pass3_verify(client, text, source, candidates):
    names = list({c.name for c in candidates if c.source_file and not c.verified})
    if not names:
        return

    prompt = f"""You are verifying evidence for software systems found in a document.

DOCUMENT TEXT:
{text}

SYSTEMS TO VERIFY: {json.dumps(names)}

For each system, find the EXACT quote from the document text that proves it exists.

Respond with a JSON object. Keys = system names, values:
- "found": true or false
- "quote": exact verbatim text snippet (max 150 chars), or null if not found
- "location": where in the text (e.g. "first paragraph", "row 3")

Only cite text that ACTUALLY EXISTS above. Do not paraphrase or invent.
Respond with ONLY valid JSON. No markdown fences."""
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            max_tokens=1500,
        )
        raw = response.choices[0].message.content.strip()
        data = _parse_json(raw)
        if not isinstance(data, dict):
            return
        for candidate in candidates:
            if candidate.name in data:
                result = data[candidate.name]
                if result.get("found") and result.get("quote"):
                    quote = result["quote"]
                    if _quote_exists_in_text(quote, text):
                        candidate.raw_evidence_quote = quote
                        candidate.source_location = result.get("location", source)
                        candidate.verified = True
                    else:
                        candidate.raw_evidence_quote = ""
                        candidate.verified = False
    except Exception:
        pass


def _quote_exists_in_text(quote: str, text: str) -> bool:
    if not quote or not text:
        return False

    def normalize(s):
        return re.sub(r'\s+', ' ', s.lower().strip())

    norm_quote = normalize(quote)
    norm_text = normalize(text)

    if norm_quote in norm_text:
        return True

    quote_words = [w for w in norm_quote.split() if len(w) > 3]
    if not quote_words:
        return False
    matches = sum(1 for w in quote_words if w in norm_text)
    return (matches / len(quote_words)) >= 0.70


def _call_llm(client, prompt, source, filename, extraction_type):
    last_error = None
    for attempt in range(3):
        try:
            log_event("llm_request", file=filename, source=source, extraction_type=extraction_type, attempt=attempt + 1)
            response = client.chat.completions.create(
                model=MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                max_tokens=1500,
            )
            raw = response.choices[0].message.content.strip()
            data = _parse_json(raw)
            if not isinstance(data, list):
                return []
            candidates = []
            for item in data:
                if not isinstance(item, dict) or not item.get("name"):
                    continue
                candidates.append(RawSystemCandidate(
                    name=str(item["name"]).strip(),
                    aliases=item.get("aliases", []),
                    category=item.get("category", "Other"),
                    auth_method=item.get("auth_method"),
                    key_entities=item.get("key_entities", []),
                    business_processes=item.get("business_processes", []),
                    criticality=item.get("criticality", "unknown"),
                    source_file=filename,
                    source_location=source,
                    extraction_type=extraction_type,
                ))
            log_event("llm_response", file=filename, extraction_type=extraction_type, candidates=len(candidates))
            return candidates
        except Exception as e:
            last_error = e
            log_event("llm_error", file=filename, extraction_type=extraction_type, attempt=attempt + 1, error=type(e).__name__, message=str(e)[:200])
            if attempt < 2:
                time.sleep(0.5 * (2 ** attempt))
    print(f"  [LLM error] {type(last_error).__name__}: {str(last_error)[:120]}")
    return []


def _parse_json(raw: str):
    raw = re.sub(r"```json\s*", "", raw)
    raw = re.sub(r"```\s*", "", raw)
    raw = raw.strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return []


def _fallback_extract(text: str, source: str, filename: str) -> list[RawSystemCandidate]:
    sentences = re.split(r"(?<=[.!?])\s+", text)
    candidates: list[RawSystemCandidate] = []

    for pattern, canonical_name, category in FALLBACK_SYSTEM_PATTERNS:
        match = re.search(pattern, text, re.I)
        if not match:
            continue

        quote = _sentence_for_match(sentences, match.group(0))
        candidates.append(
            RawSystemCandidate(
                name=canonical_name,
                aliases=[match.group(0)] if match.group(0).lower() != canonical_name.lower() else [],
                category=category,
                auth_method=None,
                key_entities=[],
                business_processes=[],
                criticality="unknown",
                source_file=filename,
                source_location=source,
                raw_evidence_quote=quote,
                extraction_type="explicit",
                verified=True,
            )
        )

    return candidates


def _sentence_for_match(sentences: list[str], matched_text: str) -> str:
    for sentence in sentences:
        if matched_text.lower() in sentence.lower():
            return sentence.strip()[:180]
    return matched_text[:180]
