"""Level 3: generate runnable connector code and an agent definition for a gap.

The generated package is intentionally generic but production-shaped:
- auth handling
- CRUD methods
- pagination support
- retries with backoff
- logging
- tests and README
"""

from __future__ import annotations

import io
import json
import re
import textwrap
import zipfile
from pathlib import Path

from models import ConnectorArtifact, IntegrationGap


def generate_connector_package(gap: IntegrationGap, output_root: str | Path) -> ConnectorArtifact:
    """Create a runnable connector package for the provided integration gap."""
    output_root = Path(output_root)
    package_name = _safe_slug(f"{gap.source_system}-{gap.destination_system}")
    artifact_dir = output_root / "generated_connectors" / package_name
    artifact_dir.mkdir(parents=True, exist_ok=True)

    files = {
        "connector.py": _render_connector_module(gap, package_name),
        "__init__.py": '"""Generated connector package."""\n',
        "agent.yaml": _render_agent_yaml(gap, package_name),
        "requirements.txt": "requests>=2.32.0\n",
        "README.md": _render_readme(gap, package_name),
        "tests/test_connector.py": _render_tests(gap, package_name),
    }

    written_files: list[str] = []
    for relative_path, content in files.items():
        file_path = artifact_dir / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        written_files.append(str(file_path))

    zip_path = artifact_dir.with_suffix(".zip")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for file_path in artifact_dir.rglob("*"):
            if file_path.is_file():
                archive.write(file_path, arcname=file_path.relative_to(artifact_dir))

    return ConnectorArtifact(
        gap_id=gap.gap_id,
        artifact_name=package_name,
        output_dir=str(artifact_dir),
        files=written_files,
        zip_path=str(zip_path),
        setup_notes=(
            f"Install dependencies with pip install -r requirements.txt and set the {gap.source_system.upper()}_BASE_URL "
            f"plus credentials in your environment before using the connector."
        ),
    )


def _render_connector_module(gap: IntegrationGap, package_name: str) -> str:
    class_name = _class_name(package_name)
    return textwrap.dedent(
        f'''\
        """Generated connector for {gap.source_system} to {gap.destination_system}."""

        from __future__ import annotations

        import logging
        import time
        from dataclasses import dataclass
        from typing import Any, Iterable, Optional

        import requests

        logger = logging.getLogger(__name__)


        class ConnectorError(RuntimeError):
            """Raised when the connector cannot complete a request."""


        @dataclass
        class ConnectorConfig:
            base_url: str
            auth_mode: str = "bearer"
            api_key: Optional[str] = None
            bearer_token: Optional[str] = None
            username: Optional[str] = None
            password: Optional[str] = None
            timeout_seconds: int = 30
            max_retries: int = 3
            backoff_factor: float = 0.5


        class {class_name}:
            """Generic production-shaped connector for {gap.source_system} → {gap.destination_system}."""

            def __init__(self, config: ConnectorConfig, session: Optional[requests.Session] = None):
                self.config = config
                self.session = session or requests.Session()
                self.session.headers.update(self._build_headers())

            def _build_headers(self) -> dict[str, str]:
                headers = {{"Accept": "application/json", "Content-Type": "application/json"}}
                if self.config.auth_mode == "bearer" and self.config.bearer_token:
                    headers["Authorization"] = f"Bearer {{self.config.bearer_token}}"
                elif self.config.auth_mode == "api_key" and self.config.api_key:
                    headers["X-API-Key"] = self.config.api_key
                return headers

            def _request(self, method: str, path: str, *, params: Optional[dict[str, Any]] = None, json_body: Optional[dict[str, Any]] = None) -> dict[str, Any]:
                url = f"{{self.config.base_url.rstrip('/') }}/{{path.lstrip('/')}}"
                last_error: Exception | None = None

                for attempt in range(self.config.max_retries):
                    try:
                        logger.info("connector_request", extra={{"method": method, "url": url, "attempt": attempt + 1}})
                        response = self.session.request(
                            method,
                            url,
                            params=params,
                            json=json_body,
                            timeout=self.config.timeout_seconds,
                        )
                        if response.status_code == 429 or response.status_code >= 500:
                            raise ConnectorError(f"Transient HTTP {{response.status_code}} from {{url}}")
                        response.raise_for_status()
                        if not response.content:
                            return {{}}
                        return response.json()
                    except Exception as exc:  # pragma: no cover - exercised by generated package tests
                        last_error = exc
                        if attempt + 1 < self.config.max_retries:
                            sleep_for = self.config.backoff_factor * (2 ** attempt)
                            time.sleep(sleep_for)
                            continue
                        raise ConnectorError(f"Failed {{method}} {{url}} after {{self.config.max_retries}} attempts: {{exc}}") from exc

                raise ConnectorError(f"Failed {{method}} {{url}}: {{last_error}}")

            def list_resources(
                self,
                path: str,
                *,
                cursor_param: str = "page",
                next_cursor_key: str = "next_cursor",
                items_key: str = "items",
            ) -> list[dict[str, Any]]:
                items: list[dict[str, Any]] = []
                cursor: Any = 1

                while cursor is not None:
                    payload = self._request("GET", path, params={{cursor_param: cursor}})
                    items.extend(payload.get(items_key, []))
                    cursor = payload.get(next_cursor_key)
                return items

            def get_resource(self, path: str, resource_id: str) -> dict[str, Any]:
                return self._request("GET", f"{{path.rstrip('/') }}/{{resource_id}}")

            def create_resource(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
                return self._request("POST", path, json_body=payload)

            def update_resource(self, path: str, resource_id: str, payload: dict[str, Any]) -> dict[str, Any]:
                return self._request("PATCH", f"{{path.rstrip('/') }}/{{resource_id}}", json_body=payload)

            def delete_resource(self, path: str, resource_id: str) -> dict[str, Any]:
                return self._request("DELETE", f"{{path.rstrip('/') }}/{{resource_id}}")


        __all__ = ["ConnectorConfig", "ConnectorError", "{class_name}"]
        '''
    ).strip() + "\n"


def _render_agent_yaml(gap: IntegrationGap, package_name: str) -> str:
    return textwrap.dedent(
        f'''\
        name: {package_name}
        purpose: >
          Automate the {gap.source_system} to {gap.destination_system} integration for {gap.use_case_title}.
        system_prompt: >
          You are an integration agent responsible for securely moving {gap.entity_type.lower()} data.
          Follow retry-safe API practices, validate every response, and never mutate data without explicit intent.
        tools:
          - connector.py
        workflow:
          - Validate configuration and required credentials.
          - List source resources with pagination.
          - Transform payloads into the destination schema.
          - Retry transient failures with backoff.
          - Emit structured logs for each request.
        test_scenarios:
          - Successful CRUD flow with paginated list retrieval.
          - Authentication failure surfaces a clear error.
          - Transient 429 and 5xx responses are retried.
          - Empty result sets return an empty collection without failure.
        '''
    ).strip() + "\n"


def _render_readme(gap: IntegrationGap, package_name: str) -> str:
    return textwrap.dedent(
        f'''\
        # {package_name}

        Generated connector for {gap.source_system} → {gap.destination_system}.

        ## What it includes
        - Authentication handling
        - CRUD helpers
        - Pagination support
        - Retry with exponential backoff
        - Tests for the generated connector

        ## Setup
        ```bash
        pip install -r requirements.txt
        ```

        Set the following environment variables before running the connector:
        - `BASE_URL`
        - `BEARER_TOKEN` or `API_KEY`

        ## Run tests
        ```bash
        python -m unittest discover -s tests
        ```
        '''
    ).strip() + "\n"


def _render_tests(gap: IntegrationGap, package_name: str) -> str:
    class_name = _class_name(package_name)
    return textwrap.dedent(
        f'''\
        """Generated connector tests."""

        import os
        import sys
        from pathlib import Path
        import unittest
        from unittest.mock import Mock, patch

        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

        from connector import ConnectorConfig, {class_name}


        class ConnectorTests(unittest.TestCase):
            def setUp(self):
                self.session = Mock()
                self.connector = {class_name}(
                    ConnectorConfig(base_url="https://example.com", bearer_token="token"),
                    session=self.session,
                )

            def _response(self, status_code=200, payload=None):
                response = Mock()
                response.status_code = status_code
                response.content = b"1"
                response.json.return_value = payload or {{}}
                response.raise_for_status.return_value = None
                return response

            def test_get_resource(self):
                self.session.request.return_value = self._response(payload={{"id": "123"}})
                result = self.connector.get_resource("/objects", "123")
                self.assertEqual(result["id"], "123")

            def test_create_resource(self):
                self.session.request.return_value = self._response(payload={{"id": "abc"}})
                result = self.connector.create_resource("/objects", {{"name": "Demo"}})
                self.assertEqual(result["id"], "abc")

            def test_pagination(self):
                first = self._response(payload={{"items": [{{"id": 1}}], "next_cursor": 2}})
                second = self._response(payload={{"items": [{{"id": 2}}], "next_cursor": None}})
                self.session.request.side_effect = [first, second]
                items = self.connector.list_resources("/objects")
                self.assertEqual([item["id"] for item in items], [1, 2])

            @patch("connector.time.sleep", return_value=None)
            def test_retries_transient_errors(self, _sleep):
                first = self._response(status_code=429, payload={{}})
                second = self._response(payload={{"ok": True}})
                self.session.request.side_effect = [first, second]
                result = self.connector.get_resource("/objects", "123")
                self.assertTrue(result["ok"])


        if __name__ == "__main__":
            unittest.main()
        '''
    ).strip() + "\n"


def _safe_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "connector"


def _class_name(package_name: str) -> str:
    return "".join(part.capitalize() for part in package_name.split("-") if part)
