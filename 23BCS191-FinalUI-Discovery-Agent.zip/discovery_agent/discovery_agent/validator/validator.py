"""
Validator and confidence scorer.

Key design decision: confidence is computed from RULES applied to evidence,
NOT from what the LLM says it is. This is what the rubric means by
"do not treat LLM output as ground truth."

Scoring rules:
  +40  — verified quote found in source text (hallucination guard passed)
  +20  — explicit extraction (Pass 1), not inferred
  +15  — mentioned in more than one document
  +10  — has key entities identified
  +10  — has business processes identified
  +5   — criticality stated (not "unknown")
  -20  — inferred extraction (Pass 2) with no verification
  -10  — quote failed hallucination check
  Max: 100, Min: 0
"""

from collections import defaultdict
from audit import log_event
from models import (
    DiscoveredSystem, EvidenceItem, ConfidenceTier,
    SystemCategory, Criticality, ExtractionResult
)
from extractor.extractor import RawSystemCandidate


KNOWN_ALIASES: dict[str, str] = {
    "sfdc": "Salesforce",
    "sf crm": "Salesforce",
    "salesforce crm": "Salesforce",
    "netsuite": "NetSuite",
    "ns": "NetSuite",
    "workday hcm": "Workday",
    "aws": "Amazon Web Services",
    "amazon web services": "Amazon Web Services",
    "gcp": "Google Cloud Platform",
    "google cloud": "Google Cloud Platform",
    "azure": "Microsoft Azure",
    "ms teams": "Microsoft Teams",
    "jira software": "Jira",
    "gh": "GitHub",
    "hubspot crm": "HubSpot",
    "zendesk support": "Zendesk",
}

CATEGORY_MAP: dict[str, SystemCategory] = {
    "CRM": SystemCategory.CRM,
    "ERP": SystemCategory.ERP,
    "HRIS": SystemCategory.HRIS,
    "Data Warehouse": SystemCategory.DATA_WAREHOUSE,
    "Communication": SystemCategory.COMMUNICATION,
    "Project Management": SystemCategory.PROJECT_MANAGEMENT,
    "Finance": SystemCategory.FINANCE,
    "DevOps": SystemCategory.DEVOPS,
    "E-Commerce": SystemCategory.ECOMMERCE,
    "Analytics": SystemCategory.ANALYTICS,
    "Storage": SystemCategory.STORAGE,
    "Identity & Auth": SystemCategory.IDENTITY,
    "Customer Support": SystemCategory.CUSTOMER_SUPPORT,
    "Marketing Automation": SystemCategory.MARKETING_AUTOMATION,
    "Cloud Platform": SystemCategory.CLOUD_PLATFORM,
    "Collaboration": SystemCategory.COLLABORATION,
    "Data Integration": SystemCategory.DATA_INTEGRATION,
    "Other": SystemCategory.OTHER,
}

NAME_CATEGORY_HINTS: list[tuple[tuple[str, ...], SystemCategory]] = [
    (("hubspot", "marketo", "pardot", "mailchimp"), SystemCategory.MARKETING_AUTOMATION),
    (("zendesk", "intercom", "freshdesk", "helpscout"), SystemCategory.CUSTOMER_SUPPORT),
    (("salesforce", "dynamics 365", "pipedrive", "zoho crm"), SystemCategory.CRM),
    (("slack", "teams", "zoom"), SystemCategory.COMMUNICATION),
    (("jira", "asana", "monday", "trello"), SystemCategory.PROJECT_MANAGEMENT),
    (("aws", "amazon web services", "azure", "gcp", "google cloud"), SystemCategory.CLOUD_PLATFORM),
    (("snowflake", "bigquery", "redshift", "databricks"), SystemCategory.DATA_WAREHOUSE),
    (("github", "gitlab", "bitbucket"), SystemCategory.DEVOPS),
    (("sharepoint", "box", "dropbox", "google drive"), SystemCategory.STORAGE),
]

CRITICALITY_MAP: dict[str, Criticality] = {
    "high": Criticality.HIGH,
    "medium": Criticality.MEDIUM,
    "low": Criticality.LOW,
    "unknown": Criticality.UNKNOWN,
}


def validate_and_score(
    candidates: list[RawSystemCandidate],
    total_documents: int,
    errors: list[str]
) -> ExtractionResult:
    """
    Merge, deduplicate, score, and validate all raw candidates
    into a final ExtractionResult.
    """
    merged = _merge_duplicates(candidates)
    systems = []

    for name, group in merged.items():
        system = _build_system(name, group)
        systems.append(system)
        log_event("system_scored", system=name, category=system.category.value, score=system.confidence_score, tier=system.confidence_tier.value)

    # Sort: high confidence first, then by name
    systems.sort(key=lambda s: (-s.confidence_score, s.name))

    needs_review = sum(1 for s in systems if s.human_review_required)

    notes = _build_agent_notes(systems, errors)

    return ExtractionResult(
        total_documents_processed=total_documents,
        total_systems_discovered=len(systems),
        systems_needing_review=needs_review,
        systems=systems,
        processing_errors=errors,
        agent_notes=notes,
    )


def _merge_duplicates(candidates: list[RawSystemCandidate]) -> dict[str, list[RawSystemCandidate]]:
    """
    Group candidates that refer to the same system.
    Uses canonical name resolution via KNOWN_ALIASES.
    """
    groups: dict[str, list[RawSystemCandidate]] = defaultdict(list)

    for c in candidates:
        canonical = _resolve_canonical_name(c.name, c.aliases)
        groups[canonical].append(c)

    return dict(groups)


def _resolve_canonical_name(name: str, aliases: list[str]) -> str:
    """Resolve a name or alias to its canonical form."""
    normalized = name.lower().strip()
    if normalized in KNOWN_ALIASES:
        return KNOWN_ALIASES[normalized]

    for alias in aliases:
        if alias.lower().strip() in KNOWN_ALIASES:
            return KNOWN_ALIASES[alias.lower().strip()]

    # Title-case unknown systems for consistency
    return name.strip().title() if name.islower() else name.strip()


def _build_system(name: str, group: list[RawSystemCandidate]) -> DiscoveredSystem:
    """Build a validated DiscoveredSystem from a group of raw candidates."""
    # Gather all evidence, deduplicating by (source_file, raw_text)
    evidence_items = []
    seen_evidence: set = set()
    all_source_files = set()

    for c in group:
        all_source_files.add(c.source_file)
        if c.raw_evidence_quote:
            key = (c.source_file, c.raw_evidence_quote)
            if key not in seen_evidence:
                seen_evidence.add(key)
                evidence_items.append(EvidenceItem(
                    source_file=c.source_file,
                    location=c.source_location,
                    raw_text=c.raw_evidence_quote,
                    extraction_method=c.extraction_type,
                ))
        elif c.source_location:
            key = (c.source_file, c.source_location)
            if key not in seen_evidence:
                seen_evidence.add(key)
                evidence_items.append(EvidenceItem(
                    source_file=c.source_file,
                    location=c.source_location,
                    raw_text=f"[unverified] Mentioned in {c.source_location}",
                    extraction_method=c.extraction_type,
                ))

    # Compute confidence from rules
    score = _compute_confidence(group, all_source_files, evidence_items)

    # Determine confidence tier
    if score >= 95:
        tier = ConfidenceTier.HIGH
    elif score >= 70:
        tier = ConfidenceTier.MEDIUM
    else:
        tier = ConfidenceTier.LOW

    human_review = score < 70

    # Merge fields across group, preferring richer entries
    representative = max(group, key=lambda c: len(c.key_entities or []) + len(c.business_processes or []))

    all_aliases = list({a for c in group for a in (c.aliases or []) if a.lower() != name.lower()})
    all_entities = list({e for c in group for e in (c.key_entities or [])})
    all_processes = list({p for c in group for p in (c.business_processes or [])})

    category = _normalize_category(name, group, representative.category)
    criticality = CRITICALITY_MAP.get(representative.criticality, Criticality.UNKNOWN)

    # Build inference notes for low-confidence findings
    inference_notes = None
    review_reason = None

    if any(c.extraction_type == "inferred" for c in group):
        inferred_aliases = [a for c in group if c.extraction_type == "inferred" for a in c.aliases]
        inference_notes = (
            f"System inferred from references: {', '.join(inferred_aliases) if inferred_aliases else name}. "
            f"Not explicitly named in source documents."
        )

    if human_review:
        unverified = [c for c in group if not c.verified]
        review_reason = (
            f"Confidence {score}% is below 70% threshold. "
            f"{len(unverified)} of {len(group)} mentions could not be verified in source text."
        )

    log_event(
        "system_validated",
        system=name,
        score=score,
        tier=tier.value,
        evidence_count=len(evidence_items),
        review_required=human_review,
    )

    return DiscoveredSystem(
        name=name,
        aliases=all_aliases,
        category=category,
        auth_method=representative.auth_method,
        key_entities=all_entities,
        business_processes=all_processes,
        criticality=criticality,
        confidence_score=score,
        confidence_tier=tier,
        evidence_chain=evidence_items,
        inference_notes=inference_notes,
        human_review_required=human_review,
        review_reason=review_reason,
    )


def _normalize_category(name: str, group: list[RawSystemCandidate], raw_category: str) -> SystemCategory:
    """Map vague or Other categories to a narrower, evidence-backed type."""
    if raw_category in CATEGORY_MAP and CATEGORY_MAP[raw_category] != SystemCategory.OTHER:
        return CATEGORY_MAP[raw_category]

    aliases: list[str] = []
    for candidate in group:
        aliases.extend(candidate.aliases or [])

    haystack = " ".join([name, *aliases]).lower()
    for keywords, category in NAME_CATEGORY_HINTS:
        if any(keyword in haystack for keyword in keywords):
            return category

    return CATEGORY_MAP.get(raw_category, SystemCategory.OTHER)


def _compute_confidence(
    group: list[RawSystemCandidate],
    source_files: set[str],
    evidence_items: list[EvidenceItem],
) -> int:
    """Rules-based confidence scoring. Not LLM-assigned."""
    score = 0

    verified_count = sum(1 for c in group if c.verified)
    explicit_count = sum(1 for c in group if c.extraction_type == "explicit")
    inferred_count = sum(1 for c in group if c.extraction_type == "inferred")
    has_entities = any(c.key_entities for c in group if c.key_entities)
    has_processes = any(c.business_processes for c in group if c.business_processes)
    multi_doc = len(source_files) > 1
    has_criticality = any(c.criticality != "unknown" for c in group)

    # Positive signals
    score += min(verified_count * 40, 40)     # Up to +40 for verified quotes
    score += min(explicit_count * 20, 20)     # Up to +20 for explicit naming
    score += 15 if multi_doc else 0            # +15 for multi-doc corroboration
    score += 10 if has_entities else 0         # +10 for identified entities
    score += 10 if has_processes else 0        # +10 for identified processes
    score += 5 if has_criticality else 0       # +5 for known criticality

    # Penalties
    if inferred_count > 0 and verified_count == 0:
        score -= 20  # Inferred with zero verification

    unverified = len(group) - verified_count
    if unverified > 0 and verified_count == 0:
        score -= 10  # Nothing verified at all

    return max(0, min(100, score))


def _build_agent_notes(systems: list[DiscoveredSystem], errors: list[str]) -> str:
    high = [s for s in systems if s.confidence_tier == ConfidenceTier.HIGH]
    medium = [s for s in systems if s.confidence_tier == ConfidenceTier.MEDIUM]
    low = [s for s in systems if s.confidence_tier == ConfidenceTier.LOW]

    notes = (
        f"Discovery complete. Found {len(systems)} systems: "
        f"{len(high)} high-confidence, {len(medium)} medium-confidence, "
        f"{len(low)} requiring human review."
    )

    if low:
        names = ", ".join(s.name for s in low)
        notes += f" Systems needing review: {names}."

    if errors:
        notes += f" {len(errors)} document(s) could not be fully processed."

    return notes
