"""Lightweight SQLite persistence for Discovery Agent runs."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ProjectStore:
    """Simple durable store for discovery runs and generated artifacts."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _initialize(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    level TEXT NOT NULL,
                    title TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    source_paths TEXT NOT NULL,
                    summary TEXT,
                    payload_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS artifacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER NOT NULL,
                    artifact_type TEXT NOT NULL,
                    path TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(run_id) REFERENCES runs(id)
                );
                """
            )

    def save_run(
        self,
        level: str,
        title: str,
        source_paths: list[str],
        payload: Any,
        summary: str | None = None,
    ) -> int:
        payload_json = json.dumps(self._serialize(payload), indent=2, default=str)
        created_at = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cursor = conn.execute(
                """
                INSERT INTO runs (level, title, created_at, source_paths, summary, payload_json)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (level, title, created_at, json.dumps(source_paths), summary, payload_json),
            )
            return int(cursor.lastrowid)

    def save_artifact(self, run_id: int, artifact_type: str, path: str, metadata: Any) -> None:
        created_at = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO artifacts (run_id, artifact_type, path, metadata_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (run_id, artifact_type, path, json.dumps(self._serialize(metadata), indent=2, default=str), created_at),
            )

    def list_runs(self, level: str | None = None) -> list[dict[str, Any]]:
        query = "SELECT * FROM runs"
        params: tuple[Any, ...] = ()
        if level:
            query += " WHERE level = ?"
            params = (level,)
        query += " ORDER BY id DESC"
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def get_run(self, run_id: int) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
        return dict(row) if row else None

    def latest_run(self, level: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM runs WHERE level = ? ORDER BY id DESC LIMIT 1",
                (level,),
            ).fetchone()
        return dict(row) if row else None

    def list_artifacts(self, run_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM artifacts WHERE run_id = ? ORDER BY id DESC",
                (run_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def _serialize(self, payload: Any) -> Any:
        if hasattr(payload, "model_dump"):
            return payload.model_dump()
        if is_dataclass(payload):
            return asdict(payload)
        if isinstance(payload, dict):
            return payload
        if isinstance(payload, list):
            return [self._serialize(item) for item in payload]
        return payload
